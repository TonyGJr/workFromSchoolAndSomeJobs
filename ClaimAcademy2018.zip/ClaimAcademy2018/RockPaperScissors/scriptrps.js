
var userOpt = prompt("Rock, Paper, Or Scissors?");
var computerOpt = Math.random();


if(computerOpt < 0.33){
	computerOpt = "rock";
} 
else if (computerOpt <= 0.66){
	computerOpt = "paper";
} 
else { 
	computerOpt= "scissors";
}

var compare = function(opt1,opt2){
    if (opt1===opt2){
       console.log("It's a tie");
    }
    if (opt1=== "rock"){
        if(opt2==="scissors"){
            console.log("Rock wins!");
        }
    	else if(opt2==="paper"){
            console.log("Paper wins!");
        }
    }
    if(opt1==="paper"){
        if(opt2==="rock"){
            console.log("Paper wins!");
        }
        else if(opt2==="scissors"){
            console.log("Scissors wins!");
        }
    }
    if(opt1==="scissors"){
        if(opt2==="rock"){
            console.log("Rock wins!");
        }
        else if(opt2==="paper"){
            console.log("Scissors win!");
        }
    }
        
    };
    console.log("Your choice: " + userOpt);
    console.log("Computer choice: " + computerOpt);
    compare(userOpt, computerOpt);
   