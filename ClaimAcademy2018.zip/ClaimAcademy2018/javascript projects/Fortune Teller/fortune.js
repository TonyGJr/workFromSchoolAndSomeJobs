var kids = 2;
var partName = "your girlfriend";
var geoLocation = "New York";
var jobTitle = "Developer";


console.log("You will be a " + jobTitle + " in " + geoLocation + ", and married to " + partName + " with " + kids + " kids.");


	// document.getElementById("fortune").innerHTML = 

