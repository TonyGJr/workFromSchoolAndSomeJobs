
var iEarned = document.querySelector("#interest");
var result = document.getElementById("total");
var button = document.getElementById("submit");


button.addEventListener("click", function(){
var rate = document.querySelector("#irate").value;
	var nY = document.querySelector("#numYears").value;
	var sBalance = document.querySelector("#sBalance").value;

	if (rate.length == 0) {
		alert("Please Enter Values");
	}
	else{
	
	// console.log("Hello World");
	var ie = sBalance*rate*nY;
	var t = parseInt(ie) + parseInt(sBalance);
	iEarned.innerText = parseInt(ie);              
    result.innerText = t;

    console.log(rate);
    console.log(nY);
    console.log(sBalance);
    console.log(iEarned);
    console.log(result);


		}})

  // cool animation 
  var c = document.getElementById("c");
var ctx = c.getContext("2d");

//making the canvas full screen
c.height = window.innerHeight;
c.width = window.innerWidth;

//letters - taken from the unicode charset
var letters = "CALCULATE YOUR INTEREST MANNNNNNNN";
//converting the string into an array of single characters
letters = letters.split("");

var font_size = 10;
var columns = c.width/font_size; //number of columns for the rain
//an array of drops - one per column
var drops = [];
//x below is the x coordinate
//1 = y co-ordinate of the drop(same for every drop initially)
for(var x = 0; x < columns; x++)
	drops[x] = 1; 

//drawing the characters
function draw()
{
	//Black BG for the canvas
	//translucent BG to show trail
	ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
	ctx.fillRect(0, 0, c.width, c.height);
	
	ctx.fillStyle = "#0F0"; //green text
	ctx.font = font_size + "px arial";
	//looping over drops
	for(var i = 0; i < drops.length; i++)
	{
		//a random letters character to print
		var text = letters[Math.floor(Math.random()*letters.length)];
		//x = i*font_size, y = value of drops[i]*font_size
		ctx.fillText(text, i*font_size, drops[i]*font_size);
		
		//sending the drop back to the top randomly after it has crossed the screen
		//adding a randomness to the reset to make the drops scattered on the Y axis
		if(drops[i]*font_size > c.height && Math.random() > 0.975)
			drops[i] = 0;
		
		//incrementing Y coordinate
		drops[i]++;
	}
}

setInterval(draw, 33);
