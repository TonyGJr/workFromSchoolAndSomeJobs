var favMovies, text, fLen, i;

favMovies = ["Jurassic World", "Hills Have Eyes", "Wrong Turn", "Jumanji", "Lion King", "Rugrats Go To Paris", "Scary Movie", "Nightmare on Elm Street", "Black Panther", "Boondocks"];


console.log("My Favorite Movies Are:")
// console.log(favMovies);

fLen = favMovies.length;
text = "<ul>";
for (i = 0; i < fLen; i++) {
    text += "<li>" + favMovies[i] + "</li>";
}
text += "</ul>";


document.getElementById("btn1").addEventListener("click", myFunction);

function myFunction() {
	
    document.getElementById("list").innerHTML = text;
}

console.log(text);