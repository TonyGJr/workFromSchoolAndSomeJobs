// document.getElementById("groceryList").addEventListener("click", myFunction);

// function myFunction() {
	
//     document.getElementById("item").style.color = "green";
//     document.getElementById("item").style.textDecoration = "line-through"
//     document.getElementById("item").style.fontStyle = 'italic';
// }
// This code is for the list that was hard coded
var li = document.querySelectorAll("li")

for (let i = 0; i < li.length; i++) {
	li[i].addEventListener("click", function() {
	li[i].classList.toggle("done")
});
}
// end of hard coded list

document.getElementById("addToList").onclick  = function() {

var input = document.querySelector("#inputText");
if (input.value.length == 0) {
	console.log('uuk')
    alert('Type item name into the box')
  }
  else {
    var node = document.createElement("Li");
    var text = document.getElementById("inputText").value; 
    var textnode=document.createTextNode(text);
    node.appendChild(textnode);
    node.addEventListener("click", function() {
    	node.classList.toggle("done")
    })
    document.getElementById("groceryList").appendChild(node);
    
}}
