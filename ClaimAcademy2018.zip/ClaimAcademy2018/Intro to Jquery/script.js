$(document).ready(function(){
    $("button").click(function(){
        var inputText = $("#inputText").val();
  		var groceryInfo = $(".groceryInfo");


		if (inputText == 0) {
		    groceryInfo.addClass("error");
		    groceryInfo.removeClass("correct");
		    groceryInfo.html("");
		  } else {
		    $("ul").append("<li>" + inputText + "</li>");
		    $("ul li").addClass("item");
		    groceryInfo.html(inputText + ' <i class="fa fa-check" aria-hidden="true"></i>');
		    groceryInfo.removeClass("error");
		    groceryInfo.addClass("correct");

		    
		    $('.correct').fadeIn(2000)
		    $('.correct').fadeOut(1000);
		   
		  }
    });
});