
// var form  = document.getElementsByTagName('form');
// var email = document.getElementById('email');
// var error = document.querySelector('.error');

// email.addEventListener("input", function (event) {
//   // Each time the user types something, we check if the
//   // email field is valid.
//   if (email === "") {
    
//     error.innerHTML = ""; // Reset the content of the message
//     error.className = "error"; // Reset the visual state of the message
//   }
// };
