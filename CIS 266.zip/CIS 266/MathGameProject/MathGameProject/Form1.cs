﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 *math game
 * 
 */

namespace MathGameProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            number1Label.Visible = false;
            number2Label.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            inputTextBox.Visible = false;
            enterButton.Visible = false;

            correctLabel.Visible = false;
            correctOutputLabel.Visible = false;
            label6.Visible = false;
            incorrectOutputLabel.Visible = false;
            label2.Visible = false;
            totalOutputLabel.Visible = false;

            label5.Visible = true;
            label1.Visible = true;
            gamesAmountTextBox.Visible = true;
            highestValueTextBox.Visible = true;
            startGameButton.Visible = true;

            correctPictureBox.Visible = false;
            wrongPictureBox.Visible = false;

        }

        Random rand = new Random();

        int gamesAmount = 0, highestValue = 0, currentGame = 0;
        int correct = 0, incorrect = 0;
        int number1, number2, sum, answer;

        private void enterButton_Click(object sender, EventArgs e)
        {

            sum = number1 + number2;

                if (int.TryParse(inputTextBox.Text, out answer))
                {
                    if (answer == sum)
                    {
                        correct = correct + 1;
                        correctPictureBox.Visible = true;
                        wrongPictureBox.Visible = false;
                        inputTextBox.Text = "";
                        inputTextBox.Focus();
                    }
                    else
                    {
                        incorrect = incorrect + 1;
                        wrongPictureBox.Visible = true;
                        correctPictureBox.Visible = false;
                        inputTextBox.Text = "";
                        inputTextBox.Focus();
                    }
                }
                else
                {
                    incorrect = incorrect + 1;
                    wrongPictureBox.Visible = true;
                    correctPictureBox.Visible = false;
                    MessageBox.Show("Invalid answer format.");
                    inputTextBox.Text = "";
                    inputTextBox.Focus();
                }
                    
                number1 = rand.Next(highestValue) + 1;
                number2 = rand.Next(highestValue) + 1;

                number1Label.Text = number1.ToString();
                number2Label.Text = number2.ToString();
                currentGame = currentGame + 1;

                correctOutputLabel.Text = correct.ToString();
                incorrectOutputLabel.Text = incorrect.ToString();
                totalOutputLabel.Text = currentGame.ToString();

                if (currentGame >= gamesAmount)
                {
                    MessageBox.Show("You got " + correct + " right and " + incorrect + " wrong out of " + gamesAmount + " problems.");
                    number1Label.Visible = false;
                    number2Label.Visible = false;
                    label3.Visible = false;
                    label4.Visible = false;
                    inputTextBox.Visible = false;
                    enterButton.Visible = false;

                    correctLabel.Visible = false;
                    correctOutputLabel.Visible = false;
                    label6.Visible = false;
                    incorrectOutputLabel.Visible = false;
                    label2.Visible = false;
                    totalOutputLabel.Visible = false;

                    label5.Visible = true;
                    label1.Visible = true;
                    gamesAmountTextBox.Visible = true;
                    highestValueTextBox.Visible = true;
                    startGameButton.Visible = true;

                    correctPictureBox.Visible = false;
                    wrongPictureBox.Visible = false;

                    gamesAmountTextBox.Text = "";
                    highestValueTextBox.Text = "";
                    gamesAmountTextBox.Focus();
                }

        }

        private void startGameButton_Click(object sender, EventArgs e)
        {
            if (int.TryParse(gamesAmountTextBox.Text, out gamesAmount))
            {
                if (int.TryParse(highestValueTextBox.Text, out highestValue))
                {
                    if (gamesAmount > 0)
                    {
                        number1Label.Visible = true;
                        number2Label.Visible = true;
                        label3.Visible = true;
                        label4.Visible = true;
                        inputTextBox.Visible = true;
                        enterButton.Visible = true;

                        correctLabel.Visible = true;
                        correctOutputLabel.Visible = true;
                        label6.Visible = true;
                        incorrectOutputLabel.Visible = true;
                        label2.Visible = true;
                        totalOutputLabel.Visible = true;

                        label5.Visible = false;
                        label1.Visible = false;
                        gamesAmountTextBox.Visible = false;
                        highestValueTextBox.Visible = false;
                        startGameButton.Visible = false;

                        currentGame = 0;
                        correct = 0;
                        incorrect = 0;

                        number1 = rand.Next(highestValue) + 1;
                        number2 = rand.Next(highestValue) + 1;

                        number1Label.Text = number1.ToString();
                        number2Label.Text = number2.ToString();

                        correctOutputLabel.Text = "0";
                        incorrectOutputLabel.Text = "0";
                        totalOutputLabel.Text = "0";
                        inputTextBox.Text = "";
                        
                    }
                    else
                        MessageBox.Show("Invalid amount of games to play, cannot be below 1.");
                }
                else
                    MessageBox.Show("Invalid highest number to use.");
            }
            else
                MessageBox.Show("Invalid amount of games to play.");

        }
    }
}
