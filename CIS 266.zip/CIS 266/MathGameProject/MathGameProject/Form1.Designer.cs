﻿namespace MathGameProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.highestValueTextBox = new System.Windows.Forms.TextBox();
            this.gamesAmountTextBox = new System.Windows.Forms.TextBox();
            this.number1Label = new System.Windows.Forms.Label();
            this.number2Label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.correctPictureBox = new System.Windows.Forms.PictureBox();
            this.wrongPictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.enterButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.totalOutputLabel = new System.Windows.Forms.Label();
            this.incorrectOutputLabel = new System.Windows.Forms.Label();
            this.correctLabel = new System.Windows.Forms.Label();
            this.correctOutputLabel = new System.Windows.Forms.Label();
            this.startGameButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.correctPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrongPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(396, 265);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(100, 20);
            this.inputTextBox.TabIndex = 0;
            // 
            // highestValueTextBox
            // 
            this.highestValueTextBox.Location = new System.Drawing.Point(437, 136);
            this.highestValueTextBox.Name = "highestValueTextBox";
            this.highestValueTextBox.Size = new System.Drawing.Size(100, 20);
            this.highestValueTextBox.TabIndex = 2;
            // 
            // gamesAmountTextBox
            // 
            this.gamesAmountTextBox.Location = new System.Drawing.Point(437, 83);
            this.gamesAmountTextBox.Name = "gamesAmountTextBox";
            this.gamesAmountTextBox.Size = new System.Drawing.Size(100, 20);
            this.gamesAmountTextBox.TabIndex = 1;
            // 
            // number1Label
            // 
            this.number1Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.number1Label.Location = new System.Drawing.Point(12, 226);
            this.number1Label.Name = "number1Label";
            this.number1Label.Size = new System.Drawing.Size(103, 68);
            this.number1Label.TabIndex = 5;
            // 
            // number2Label
            // 
            this.number2Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.number2Label.Location = new System.Drawing.Point(193, 226);
            this.number2Label.Name = "number2Label";
            this.number2Label.Size = new System.Drawing.Size(103, 68);
            this.number2Label.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(121, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 68);
            this.label3.TabIndex = 7;
            this.label3.Text = "+";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(307, 226);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 68);
            this.label4.TabIndex = 8;
            this.label4.Text = "=";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(190, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(230, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "How many games would you like to play today?";
            // 
            // correctPictureBox
            // 
            this.correctPictureBox.Location = new System.Drawing.Point(25, 61);
            this.correctPictureBox.Name = "correctPictureBox";
            this.correctPictureBox.Size = new System.Drawing.Size(147, 111);
            this.correctPictureBox.TabIndex = 10;
            this.correctPictureBox.TabStop = false;
            // 
            // wrongPictureBox
            // 
            this.wrongPictureBox.Location = new System.Drawing.Point(590, 45);
            this.wrongPictureBox.Name = "wrongPictureBox";
            this.wrongPictureBox.Size = new System.Drawing.Size(147, 111);
            this.wrongPictureBox.TabIndex = 11;
            this.wrongPictureBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(190, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Highest number you want to use in the game?";
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(335, 323);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(95, 44);
            this.enterButton.TabIndex = 13;
            this.enterButton.Text = "Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(479, 385);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 33);
            this.label2.TabIndex = 22;
            this.label2.Text = "Total:";
            this.label2.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(300, 385);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 33);
            this.label6.TabIndex = 21;
            this.label6.Text = "Incorrect:";
            this.label6.Visible = false;
            // 
            // totalOutputLabel
            // 
            this.totalOutputLabel.BackColor = System.Drawing.Color.White;
            this.totalOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalOutputLabel.Font = new System.Drawing.Font("Comic Sans MS", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalOutputLabel.ForeColor = System.Drawing.Color.Black;
            this.totalOutputLabel.Location = new System.Drawing.Point(472, 430);
            this.totalOutputLabel.Name = "totalOutputLabel";
            this.totalOutputLabel.Size = new System.Drawing.Size(100, 67);
            this.totalOutputLabel.TabIndex = 20;
            this.totalOutputLabel.Visible = false;
            // 
            // incorrectOutputLabel
            // 
            this.incorrectOutputLabel.BackColor = System.Drawing.Color.White;
            this.incorrectOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.incorrectOutputLabel.Font = new System.Drawing.Font("Comic Sans MS", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.incorrectOutputLabel.ForeColor = System.Drawing.Color.Black;
            this.incorrectOutputLabel.Location = new System.Drawing.Point(306, 430);
            this.incorrectOutputLabel.Name = "incorrectOutputLabel";
            this.incorrectOutputLabel.Size = new System.Drawing.Size(100, 67);
            this.incorrectOutputLabel.TabIndex = 17;
            this.incorrectOutputLabel.Visible = false;
            // 
            // correctLabel
            // 
            this.correctLabel.AutoSize = true;
            this.correctLabel.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correctLabel.Location = new System.Drawing.Point(143, 385);
            this.correctLabel.Name = "correctLabel";
            this.correctLabel.Size = new System.Drawing.Size(106, 33);
            this.correctLabel.TabIndex = 16;
            this.correctLabel.Text = "Correct:";
            this.correctLabel.Visible = false;
            // 
            // correctOutputLabel
            // 
            this.correctOutputLabel.BackColor = System.Drawing.Color.White;
            this.correctOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.correctOutputLabel.Font = new System.Drawing.Font("Comic Sans MS", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correctOutputLabel.ForeColor = System.Drawing.Color.Black;
            this.correctOutputLabel.Location = new System.Drawing.Point(142, 430);
            this.correctOutputLabel.Name = "correctOutputLabel";
            this.correctOutputLabel.Size = new System.Drawing.Size(100, 67);
            this.correctOutputLabel.TabIndex = 15;
            this.correctOutputLabel.Visible = false;
            // 
            // startGameButton
            // 
            this.startGameButton.Location = new System.Drawing.Point(464, 323);
            this.startGameButton.Name = "startGameButton";
            this.startGameButton.Size = new System.Drawing.Size(95, 44);
            this.startGameButton.TabIndex = 23;
            this.startGameButton.Text = "Start Game";
            this.startGameButton.UseVisualStyleBackColor = true;
            this.startGameButton.Click += new System.EventHandler(this.startGameButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(762, 521);
            this.Controls.Add(this.startGameButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.totalOutputLabel);
            this.Controls.Add(this.incorrectOutputLabel);
            this.Controls.Add(this.correctLabel);
            this.Controls.Add(this.correctOutputLabel);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.wrongPictureBox);
            this.Controls.Add(this.correctPictureBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.number2Label);
            this.Controls.Add(this.number1Label);
            this.Controls.Add(this.gamesAmountTextBox);
            this.Controls.Add(this.highestValueTextBox);
            this.Controls.Add(this.inputTextBox);
            this.Name = "Form1";
            this.Text = "Math Game";
            ((System.ComponentModel.ISupportInitialize)(this.correctPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrongPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.TextBox highestValueTextBox;
        private System.Windows.Forms.TextBox gamesAmountTextBox;
        private System.Windows.Forms.Label number1Label;
        private System.Windows.Forms.Label number2Label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox correctPictureBox;
        private System.Windows.Forms.PictureBox wrongPictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label totalOutputLabel;
        private System.Windows.Forms.Label incorrectOutputLabel;
        private System.Windows.Forms.Label correctLabel;
        private System.Windows.Forms.Label correctOutputLabel;
        private System.Windows.Forms.Button startGameButton;
    }
}

