﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GunnFinalExam
{
   public class Student
    {
        //field variables

        private string _name;
        private double _hours;


        // Constructors
            //null constructors

        public Student()
        {
            _name = "";
            _hours = 0;

        }

        // overloaded constructors

        public Student(string theName, double theHours)
        {
          

            Name = theName;
            Hours = theHours;
        }

        // Properties

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public double Hours
        {
            get { return _hours; }
            set { _hours = value; }
        }


        // Other Methods


        // calc  the activity fees

        public double CalcActivityFees()
        {
            double activityFee = 0;

            if (_hours <= 12)
            {
                activityFee = 200;
                
            }

            else
            {
                activityFee = 100;

            }


            return activityFee;
        }
    }
}

