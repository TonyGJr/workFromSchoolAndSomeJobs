﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GunnFinalExam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayFeesBtn_Click(object sender, EventArgs e)
        {

            string tempName = "";
            double tempHours = 0;

            //instantiate an Student object         

            Student theStudent = new Student();

            // assign the data to the properties of the Student object
            tempName = nameTB.Text;
            theStudent.Name = tempName;
            theStudent.Hours = tempHours;

            Student Student = new Student(tempName, tempHours);

            //calc the activity; pass theStudent to the method

            CalcActivityFees(theStudent);

        }
        private void CalcActivityFees(Student aStudent)
        {
            // display output
            double activityFee = 0;

            activityFee = aStudent.CalcActivityFees();


            // instiate a new form object and display the data in that form

            DisplayForm dsForm = new DisplayForm(aStudent);

            //this will actually force us to leave this form and show the Display Form
            dsForm.ShowDialog();

        }



    }
}
