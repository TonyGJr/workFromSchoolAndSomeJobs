﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GunnFinalExam
{
    public partial class DisplayForm : Form
    {
        //Field
        Student _stu;

        // Constructor method
        public DisplayForm()
        {
            InitializeComponent();
        }

        public DisplayForm(Student theStudent)
        {
            InitializeComponent();
            _stu = theStudent;

        }

        private void displayStuActFeesBtn_Click(object sender, EventArgs e)
        {
            // display the student data
            displayLbl.Text = "Name: " + _stu.Name + "\n"
                            + "Hours: " + _stu.Hours.ToString("n2") + "\n"
                            + "Activity Fees: "; // + _stu.CalcActivityFees.ToString("c2");



        }

        private void closeAndReturnBtn_Click(object sender, EventArgs e)
        {
            this.Close();
            

        }
    }
}
