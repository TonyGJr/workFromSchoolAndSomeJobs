﻿namespace GunnFinalExam
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nameTB = new System.Windows.Forms.TextBox();
            this.hoursTB = new System.Windows.Forms.TextBox();
            this.displayFeesBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Full Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Hours Enrolled:";
            // 
            // nameTB
            // 
            this.nameTB.Location = new System.Drawing.Point(140, 57);
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(118, 20);
            this.nameTB.TabIndex = 2;
            // 
            // hoursTB
            // 
            this.hoursTB.Location = new System.Drawing.Point(140, 103);
            this.hoursTB.Name = "hoursTB";
            this.hoursTB.Size = new System.Drawing.Size(118, 20);
            this.hoursTB.TabIndex = 3;
            // 
            // displayFeesBtn
            // 
            this.displayFeesBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayFeesBtn.Location = new System.Drawing.Point(89, 186);
            this.displayFeesBtn.Name = "displayFeesBtn";
            this.displayFeesBtn.Size = new System.Drawing.Size(131, 79);
            this.displayFeesBtn.TabIndex = 4;
            this.displayFeesBtn.Text = "Display Activity Fees";
            this.displayFeesBtn.UseVisualStyleBackColor = true;
            this.displayFeesBtn.Click += new System.EventHandler(this.displayFeesBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(322, 335);
            this.Controls.Add(this.displayFeesBtn);
            this.Controls.Add(this.hoursTB);
            this.Controls.Add(this.nameTB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "MainForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nameTB;
        private System.Windows.Forms.TextBox hoursTB;
        private System.Windows.Forms.Button displayFeesBtn;
    }
}

