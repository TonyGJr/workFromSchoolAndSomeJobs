﻿namespace ListAndSwitchExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.colorListBox = new System.Windows.Forms.ListBox();
            this.displayLbl = new System.Windows.Forms.Label();
            this.showBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // colorListBox
            // 
            this.colorListBox.FormattingEnabled = true;
            this.colorListBox.Items.AddRange(new object[] {
            "Red",
            "Blue",
            "Green",
            "Purple"});
            this.colorListBox.Location = new System.Drawing.Point(130, 63);
            this.colorListBox.Name = "colorListBox";
            this.colorListBox.Size = new System.Drawing.Size(110, 43);
            this.colorListBox.TabIndex = 0;
            // 
            // displayLbl
            // 
            this.displayLbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.displayLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayLbl.Location = new System.Drawing.Point(72, 146);
            this.displayLbl.Name = "displayLbl";
            this.displayLbl.Size = new System.Drawing.Size(226, 72);
            this.displayLbl.TabIndex = 1;
            // 
            // showBtn
            // 
            this.showBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showBtn.Location = new System.Drawing.Point(130, 241);
            this.showBtn.Name = "showBtn";
            this.showBtn.Size = new System.Drawing.Size(101, 41);
            this.showBtn.TabIndex = 2;
            this.showBtn.Text = "Show";
            this.showBtn.UseVisualStyleBackColor = true;
            this.showBtn.Click += new System.EventHandler(this.showBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 331);
            this.Controls.Add(this.showBtn);
            this.Controls.Add(this.displayLbl);
            this.Controls.Add(this.colorListBox);
            this.Name = "Form1";
            this.Text = "List and Switch Example";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox colorListBox;
        private System.Windows.Forms.Label displayLbl;
        private System.Windows.Forms.Button showBtn;
    }
}

