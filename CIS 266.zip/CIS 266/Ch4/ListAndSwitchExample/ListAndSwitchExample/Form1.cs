﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListAndSwitchExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            int colorNum = 0;

            if (colorListBox.SelectedIndex != -1)
            {
                // show the font color of selected item

                colorNum = (colorListBox.SelectedIndex);

            switch(colorNum)
                {
                    case 0:
                        {
                            displayLbl.ForeColor = Color.Red;
                            displayLbl.Text = "You selected RED";
                            break;
                        }
                    case 1:
                        {
                            displayLbl.ForeColor = Color.Blue;
                            displayLbl.Text = "You selected BLUE";
                            break;
                        }
                    case 2:
                        {
                            displayLbl.ForeColor = Color.Green;
                            displayLbl.Text = "You selected GREEN";
                            break;
                        }
                    case 3:
                        {
                            displayLbl.ForeColor = Color.Purple;
                            displayLbl.Text = "You selected Purple";
                            break;
                        }
                    default:
                        {
                            displayLbl.ForeColor = Color.Black;
                            displayLbl.Text = "You selected BLACK";
                            break;
                        }
                }

            }
            else
            {
                MessageBox.Show("Please select a color from the list box");
            }

        }
    }
}
