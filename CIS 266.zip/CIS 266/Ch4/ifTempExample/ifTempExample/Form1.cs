﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ifTempExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            //capture the input
            double temp = 0;

            string outputString = "";

            //cast the temp input
            temp = double.Parse(tempTb.Text);

            // if else if statement to make suggestion

            if(temp < 32)
            {
                outputString = "Grab Your Coat, Hat, and Gloves! It's Freakin' Cold!";

            }

            else if (temp < 55)
            {
                outputString = "Get Your Jacket! It's a Little Chilly!";
            }

            else if (temp < 75)
            {
                outputString = "It Feel Good, Da Da Da Da!";
            }

            else
            {
                outputString = "It could get HOT!";
            }

            displayLbl.Text = outputString;  
        }
    }
}
