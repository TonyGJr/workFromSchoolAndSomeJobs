﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//Gunn, Tony
//09/20/2017
//This program will calculate mpg and display governemnt issued tax amount from Government Bill
namespace GasUsageBill
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {

            //Set my constant variables
            const double TAX_1 = 1.00;
            const double TAX_2 = 3.00;
            const double TAX_3 = 10.00;

            //set me other variables
            double mpg = 0;
            double milesTraveled = 0;
            double gasUsed = 0;
            double calTax = 0;


            string output = "";

            //Parse user input to correct type

            if (double.TryParse(milesTraveledTb.Text, out milesTraveled))
            {
                if (double.TryParse(gasUsedTb.Text, out gasUsed))
                {
                    //Cal mgp
                    mpg = milesTraveled / gasUsed;

                    //if else if statement begins
                    if (mpg > 25)
                    {
                        calTax = 0;
                        //change background color of display label
                        displayLbl.BackColor = Color.LightGreen;
                        titleLbl.BackColor = Color.LightGreen;
                        makeLbl.BackColor = Color.LightGreen;
                        modelLbl.BackColor = Color.LightGreen;
                        milesLbl.BackColor = Color.LightGreen;
                        gasLbl.BackColor = Color.LightGreen;

                    }

                    else if (mpg > 20)
                    {
                        calTax = TAX_1;
                        //change background color of display label
                        displayLbl.BackColor = Color.Yellow;
                        titleLbl.BackColor = Color.Yellow;
                        makeLbl.BackColor = Color.Yellow;
                        modelLbl.BackColor = Color.Yellow;
                        milesLbl.BackColor = Color.Yellow;
                        gasLbl.BackColor = Color.Yellow;
                    }
                    else if (mpg > 15)
                    {
                        calTax = TAX_2;
                        //change background color of display label
                        displayLbl.BackColor = Color.Orange;
                        titleLbl.BackColor = Color.Orange;
                        makeLbl.BackColor = Color.Orange;
                        modelLbl.BackColor = Color.Orange;
                        milesLbl.BackColor = Color.Orange;
                        gasLbl.BackColor = Color.Orange;
                    }
                    else
                    {
                        calTax = TAX_3;
                        //change background color of display label
                        displayLbl.BackColor = Color.Red;
                        titleLbl.BackColor = Color.Red;
                        makeLbl.BackColor = Color.Red;
                        modelLbl.BackColor = Color.Red;
                        milesLbl.BackColor = Color.Red;
                        gasLbl.BackColor = Color.Red;
                    }

                    //display results
                    output = makeTb.Text + " " + modelTb.Text +
                        "\n Your vehicle has been drove " + milesTraveled.ToString("n1") + " miles and used " + gasUsed.ToString("n1") + " gallons of gas, so" +
                        "\n Your MPG is: " + mpg.ToString("n2") +
                        "\n Considering Your MPG, Your Tax is: " + calTax.ToString("c") +
                        "\n Please Remember We All Have A Social Responsiblity To Watch Our Carbon FootPrint!";

                    displayLbl.Text = output;
                }
                else
                {
                    MessageBox.Show("Please Enter a Valid Number for Gas Used");
                    gasUsedTb.Text = "";
                    gasUsedTb.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please Enter a Valid Number for Miles Traveled");
                milesTraveledTb.Text = "";
                milesTraveledTb.Focus();
            }
                      
        }
        private void clearBtn_Click(object sender, EventArgs e)
        {
            //Clear text values, focus back to top, and changes colors of lbls back to my default
            makeTb.Text = "";
            modelTb.Text = "";
            milesTraveledTb.Text = "";
            gasUsedTb.Text = "";
            displayLbl.Text = "";
            makeTb.Focus();

            displayLbl.BackColor = Color.Aqua;
            titleLbl.BackColor = Color.White;
            makeLbl.BackColor = Color.Transparent;
            modelLbl.BackColor = Color.Transparent;
            milesLbl.BackColor = Color.Transparent;
            gasLbl.BackColor = Color.Transparent;
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            //exit program
            this.Close();
        }
    }
}
