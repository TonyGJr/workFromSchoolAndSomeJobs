﻿namespace GasUsageBill
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.makeLbl = new System.Windows.Forms.Label();
            this.modelLbl = new System.Windows.Forms.Label();
            this.gasLbl = new System.Windows.Forms.Label();
            this.milesLbl = new System.Windows.Forms.Label();
            this.makeTb = new System.Windows.Forms.TextBox();
            this.milesTraveledTb = new System.Windows.Forms.TextBox();
            this.gasUsedTb = new System.Windows.Forms.TextBox();
            this.modelTb = new System.Windows.Forms.TextBox();
            this.displayBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.displayLbl = new System.Windows.Forms.Label();
            this.titleLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // makeLbl
            // 
            this.makeLbl.AutoSize = true;
            this.makeLbl.BackColor = System.Drawing.Color.Transparent;
            this.makeLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.makeLbl.ForeColor = System.Drawing.Color.Aqua;
            this.makeLbl.Location = new System.Drawing.Point(35, 93);
            this.makeLbl.Name = "makeLbl";
            this.makeLbl.Size = new System.Drawing.Size(66, 24);
            this.makeLbl.TabIndex = 0;
            this.makeLbl.Text = "Make:";
            // 
            // modelLbl
            // 
            this.modelLbl.AutoSize = true;
            this.modelLbl.BackColor = System.Drawing.Color.Transparent;
            this.modelLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modelLbl.ForeColor = System.Drawing.Color.Aqua;
            this.modelLbl.Location = new System.Drawing.Point(35, 131);
            this.modelLbl.Name = "modelLbl";
            this.modelLbl.Size = new System.Drawing.Size(74, 24);
            this.modelLbl.TabIndex = 1;
            this.modelLbl.Text = "Model:";
            // 
            // gasLbl
            // 
            this.gasLbl.AutoSize = true;
            this.gasLbl.BackColor = System.Drawing.Color.Transparent;
            this.gasLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gasLbl.ForeColor = System.Drawing.Color.Aqua;
            this.gasLbl.Location = new System.Drawing.Point(35, 200);
            this.gasLbl.Name = "gasLbl";
            this.gasLbl.Size = new System.Drawing.Size(106, 24);
            this.gasLbl.TabIndex = 2;
            this.gasLbl.Text = "Gas Used:";
            // 
            // milesLbl
            // 
            this.milesLbl.AutoSize = true;
            this.milesLbl.BackColor = System.Drawing.Color.Transparent;
            this.milesLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.milesLbl.ForeColor = System.Drawing.Color.Aqua;
            this.milesLbl.Location = new System.Drawing.Point(35, 166);
            this.milesLbl.Name = "milesLbl";
            this.milesLbl.Size = new System.Drawing.Size(153, 24);
            this.milesLbl.TabIndex = 3;
            this.milesLbl.Text = "Miles Traveled:";
            // 
            // makeTb
            // 
            this.makeTb.Location = new System.Drawing.Point(185, 98);
            this.makeTb.Name = "makeTb";
            this.makeTb.Size = new System.Drawing.Size(150, 20);
            this.makeTb.TabIndex = 0;
            // 
            // milesTraveledTb
            // 
            this.milesTraveledTb.Location = new System.Drawing.Point(185, 170);
            this.milesTraveledTb.Name = "milesTraveledTb";
            this.milesTraveledTb.Size = new System.Drawing.Size(150, 20);
            this.milesTraveledTb.TabIndex = 2;
            // 
            // gasUsedTb
            // 
            this.gasUsedTb.Location = new System.Drawing.Point(185, 205);
            this.gasUsedTb.Name = "gasUsedTb";
            this.gasUsedTb.Size = new System.Drawing.Size(150, 20);
            this.gasUsedTb.TabIndex = 3;
            // 
            // modelTb
            // 
            this.modelTb.Location = new System.Drawing.Point(185, 131);
            this.modelTb.Name = "modelTb";
            this.modelTb.Size = new System.Drawing.Size(150, 20);
            this.modelTb.TabIndex = 1;
            // 
            // displayBtn
            // 
            this.displayBtn.BackColor = System.Drawing.Color.White;
            this.displayBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayBtn.Location = new System.Drawing.Point(68, 249);
            this.displayBtn.Name = "displayBtn";
            this.displayBtn.Size = new System.Drawing.Size(102, 44);
            this.displayBtn.TabIndex = 8;
            this.displayBtn.Text = "Display Results";
            this.displayBtn.UseVisualStyleBackColor = false;
            this.displayBtn.Click += new System.EventHandler(this.displayBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.BackColor = System.Drawing.Color.White;
            this.clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.Location = new System.Drawing.Point(268, 249);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(102, 44);
            this.clearBtn.TabIndex = 9;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = false;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.BackColor = System.Drawing.Color.White;
            this.exitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBtn.Location = new System.Drawing.Point(479, 249);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(102, 44);
            this.exitBtn.TabIndex = 10;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = false;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // displayLbl
            // 
            this.displayLbl.BackColor = System.Drawing.Color.Aqua;
            this.displayLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayLbl.Location = new System.Drawing.Point(370, 83);
            this.displayLbl.Name = "displayLbl";
            this.displayLbl.Size = new System.Drawing.Size(251, 149);
            this.displayLbl.TabIndex = 11;
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.BackColor = System.Drawing.Color.White;
            this.titleLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLbl.Location = new System.Drawing.Point(71, 29);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(493, 37);
            this.titleLbl.TabIndex = 12;
            this.titleLbl.Text = "Your Gas Determines Your Tax";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(633, 317);
            this.Controls.Add(this.titleLbl);
            this.Controls.Add(this.displayLbl);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.displayBtn);
            this.Controls.Add(this.modelTb);
            this.Controls.Add(this.gasUsedTb);
            this.Controls.Add(this.milesTraveledTb);
            this.Controls.Add(this.makeTb);
            this.Controls.Add(this.milesLbl);
            this.Controls.Add(this.gasLbl);
            this.Controls.Add(this.modelLbl);
            this.Controls.Add(this.makeLbl);
            this.Name = "Form1";
            this.Text = "Gas Usage Bill Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label makeLbl;
        private System.Windows.Forms.Label modelLbl;
        private System.Windows.Forms.Label gasLbl;
        private System.Windows.Forms.Label milesLbl;
        private System.Windows.Forms.TextBox makeTb;
        private System.Windows.Forms.TextBox milesTraveledTb;
        private System.Windows.Forms.TextBox gasUsedTb;
        private System.Windows.Forms.TextBox modelTb;
        private System.Windows.Forms.Button displayBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label displayLbl;
        private System.Windows.Forms.Label titleLbl;
    }
}

