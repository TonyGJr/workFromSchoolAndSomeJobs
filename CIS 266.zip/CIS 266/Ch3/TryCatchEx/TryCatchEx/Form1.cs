﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TryCatchEx
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Gunn, Tony
        //09/07/2017
        //Example of Try Catch Blocks as well as Field Variables

        // Field variables

        private int totalOrders = 0;
        private void calBtn_Click(object sender, EventArgs e)
        {
            // calculate the price of the order using try catch blocks

            try
            {
                int quantity = 0;
                double price = 0;
                double total = 0;

                string output = "";


                quantity = int.Parse(quantityTb.Text);
                price = double.Parse(priceTb.Text);

                //calc the total

                total = quantity * price;

                // add one to total

                totalOrders = totalOrders + 1;

                //output the data into label
                output = "Quantity Ordered:  " + quantity.ToString("n0") +
                        "\n Price Per Order:  " + price.ToString("c2") +
                        "\n Total Charge:  " + total.ToString("c2");

                displayLbl.Text = output;

                    
            }

            catch
            {
                //display a message is an exception in thrown
                MessageBox.Show("An error occured. Please correct and click Calculate.");
            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            // clear the textboxes and label
            priceTb.Text = "";
            quantityTb.Text = "";
            displayLbl.Text = "";

            priceTb.Focus();
        }

        private void totalOrdersBtn_Click(object sender, EventArgs e)
        {
            // Total number of orders placed

            displayLbl.Text = "Total Number of Orders: " + totalOrders.ToString("n0");

        }
    }
}
