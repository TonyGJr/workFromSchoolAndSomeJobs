﻿namespace OrderFastFoodHw5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.entreeLbl = new System.Windows.Forms.Label();
            this.drinkLbl = new System.Windows.Forms.Label();
            this.dessertLbl = new System.Windows.Forms.Label();
            this.entreeTb = new System.Windows.Forms.TextBox();
            this.drinkTb = new System.Windows.Forms.TextBox();
            this.dessertTb = new System.Windows.Forms.TextBox();
            this.addBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.totalBtn = new System.Windows.Forms.Button();
            this.outputLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // entreeLbl
            // 
            this.entreeLbl.AutoSize = true;
            this.entreeLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.entreeLbl.Location = new System.Drawing.Point(82, 40);
            this.entreeLbl.Name = "entreeLbl";
            this.entreeLbl.Size = new System.Drawing.Size(62, 18);
            this.entreeLbl.TabIndex = 0;
            this.entreeLbl.Text = "Entree:";
            // 
            // drinkLbl
            // 
            this.drinkLbl.AutoSize = true;
            this.drinkLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drinkLbl.Location = new System.Drawing.Point(82, 78);
            this.drinkLbl.Name = "drinkLbl";
            this.drinkLbl.Size = new System.Drawing.Size(53, 18);
            this.drinkLbl.TabIndex = 1;
            this.drinkLbl.Text = "Drink:";
            // 
            // dessertLbl
            // 
            this.dessertLbl.AutoSize = true;
            this.dessertLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dessertLbl.Location = new System.Drawing.Point(82, 114);
            this.dessertLbl.Name = "dessertLbl";
            this.dessertLbl.Size = new System.Drawing.Size(72, 18);
            this.dessertLbl.TabIndex = 2;
            this.dessertLbl.Text = "Dessert:";
            // 
            // entreeTb
            // 
            this.entreeTb.Location = new System.Drawing.Point(186, 37);
            this.entreeTb.Name = "entreeTb";
            this.entreeTb.Size = new System.Drawing.Size(100, 20);
            this.entreeTb.TabIndex = 3;
            // 
            // drinkTb
            // 
            this.drinkTb.Location = new System.Drawing.Point(186, 75);
            this.drinkTb.Name = "drinkTb";
            this.drinkTb.Size = new System.Drawing.Size(100, 20);
            this.drinkTb.TabIndex = 4;
            // 
            // dessertTb
            // 
            this.dessertTb.Location = new System.Drawing.Point(186, 111);
            this.dessertTb.Name = "dessertTb";
            this.dessertTb.Size = new System.Drawing.Size(100, 20);
            this.dessertTb.TabIndex = 5;
            // 
            // addBtn
            // 
            this.addBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBtn.Location = new System.Drawing.Point(33, 171);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(102, 39);
            this.addBtn.TabIndex = 6;
            this.addBtn.Text = "Add";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.Location = new System.Drawing.Point(171, 171);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(102, 39);
            this.clearBtn.TabIndex = 7;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // totalBtn
            // 
            this.totalBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalBtn.Location = new System.Drawing.Point(304, 171);
            this.totalBtn.Name = "totalBtn";
            this.totalBtn.Size = new System.Drawing.Size(102, 39);
            this.totalBtn.TabIndex = 8;
            this.totalBtn.Text = "Total";
            this.totalBtn.UseVisualStyleBackColor = true;
            this.totalBtn.Click += new System.EventHandler(this.totalBtn_Click);
            // 
            // outputLbl
            // 
            this.outputLbl.BackColor = System.Drawing.Color.White;
            this.outputLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLbl.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputLbl.Location = new System.Drawing.Point(29, 240);
            this.outputLbl.Name = "outputLbl";
            this.outputLbl.Size = new System.Drawing.Size(376, 166);
            this.outputLbl.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(444, 428);
            this.Controls.Add(this.outputLbl);
            this.Controls.Add(this.totalBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.dessertTb);
            this.Controls.Add(this.drinkTb);
            this.Controls.Add(this.entreeTb);
            this.Controls.Add(this.dessertLbl);
            this.Controls.Add(this.drinkLbl);
            this.Controls.Add(this.entreeLbl);
            this.Name = "Form1";
            this.Text = "Food Total Bill";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label entreeLbl;
        private System.Windows.Forms.Label drinkLbl;
        private System.Windows.Forms.Label dessertLbl;
        private System.Windows.Forms.TextBox entreeTb;
        private System.Windows.Forms.TextBox drinkTb;
        private System.Windows.Forms.TextBox dessertTb;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button totalBtn;
        private System.Windows.Forms.Label outputLbl;
    }
}

