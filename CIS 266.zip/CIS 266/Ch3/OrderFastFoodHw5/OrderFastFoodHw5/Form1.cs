﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrderFastFoodHw5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Gunn, Tony
        //09/11/2017
        //This program will calculate a fast food bill.


        //Field Variables

        private double total = 0;
        private double orderTotal = 0;


        private void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                double entreePrice = 0;
                double drinkPrice = 0;
                double dessertPrice = 0;
 

                const double TIP_RATE = 0.15;
                const double SALES_TAX = 0.07;

                string output = "";

                entreePrice = double.Parse(entreeTb.Text);
                drinkPrice = double.Parse(drinkTb.Text);
                dessertPrice = double.Parse(dessertTb.Text);

               

                //calc the total

                total = entreePrice + drinkPrice + dessertPrice;

                //Tip and Sales Tax

                orderTotal = (total * TIP_RATE) + (total * SALES_TAX) + total;

                //output the data to lbl
                output = "Entree Price: " + entreePrice.ToString("c") +
                    "\n Drink Price: " + drinkPrice.ToString("c") +
                    "\n Dessert Price: " + dessertPrice.ToString("c") +
                    "\n Your Total Before Tax & Tip: " + total.ToString("c");

                outputLbl.Text = output;

            }
            catch
            {
                //diaplay message is an exception thrown
                MessageBox.Show("An error occured. Please correct and click Add.");
            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            //clear the form

            entreeTb.Text = "";
            drinkTb.Text = "";
            dessertTb.Text = "";
            outputLbl.Text = "";

            entreeTb.Focus();
        }

        private void totalBtn_Click(object sender, EventArgs e)
        {
            outputLbl.Text = "Total with Tax(7%) & Tip(15%): " + orderTotal.ToString("c");

        }
    }
}
