﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Gunn, Tony
//09/05/2017
//this program will generate a mailing label
namespace MailingListHw3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            string output = "";

            output = nameTextBox.Text + "\n" + addressTextBox.Text + "\n " 
                + cityTextBox.Text + ", " + stateTextBox.Text + " " + zipTextBox.Text;

            showLbl.Text = output;
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            nameTextBox.Text = "";
            addressTextBox.Text = "";
            cityTextBox.Text = "";
            zipTextBox.Text = "";
            stateTextBox.Text = "";
            showLbl.Text = "";

        }

       
    }
}
