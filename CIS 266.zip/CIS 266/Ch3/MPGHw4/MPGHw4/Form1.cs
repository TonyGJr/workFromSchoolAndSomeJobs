﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Gunn, Tony
//09/07/2017
//This program will calculate mpg (added Year of Car)
namespace MPGHw4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            double miles = 0;
            double gasUsed = 0;
            double mpg = 0;

            miles = double.Parse(milesTb.Text);
            gasUsed = double.Parse(gasTb.Text);
            mpg = miles / gasUsed;

            //Display into outputLbl

            outputLbl.Text = nameTb.Text + "\n" +
                             yearTb.Text + "\n" +
                             makeTb.Text + "\n" +
                             modelTb.Text + "\n" +
                             "Your MPG is:" +
                             mpg.ToString("f2");
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            nameTb.Text = "";
            yearTb.Text = "";
            makeTb.Text = "";
            modelTb.Text = "";
            milesTb.Text = "";
            gasTb.Text = "";

            nameTb.Focus();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
