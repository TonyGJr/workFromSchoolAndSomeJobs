﻿namespace MPGHw4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLbl = new System.Windows.Forms.Label();
            this.makeLbl = new System.Windows.Forms.Label();
            this.modelLbl = new System.Windows.Forms.Label();
            this.milesLbl = new System.Windows.Forms.Label();
            this.gasLbl = new System.Windows.Forms.Label();
            this.outputLbl = new System.Windows.Forms.Label();
            this.nameTb = new System.Windows.Forms.TextBox();
            this.makeTb = new System.Windows.Forms.TextBox();
            this.modelTb = new System.Windows.Forms.TextBox();
            this.milesTb = new System.Windows.Forms.TextBox();
            this.gasTb = new System.Windows.Forms.TextBox();
            this.displayBtn = new System.Windows.Forms.Button();
            this.yearLbl = new System.Windows.Forms.Label();
            this.yearTb = new System.Windows.Forms.TextBox();
            this.clearBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.Location = new System.Drawing.Point(42, 29);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(57, 18);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "Name:";
            // 
            // makeLbl
            // 
            this.makeLbl.AutoSize = true;
            this.makeLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.makeLbl.Location = new System.Drawing.Point(45, 116);
            this.makeLbl.Name = "makeLbl";
            this.makeLbl.Size = new System.Drawing.Size(54, 18);
            this.makeLbl.TabIndex = 1;
            this.makeLbl.Text = "Make:";
            // 
            // modelLbl
            // 
            this.modelLbl.AutoSize = true;
            this.modelLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modelLbl.Location = new System.Drawing.Point(45, 157);
            this.modelLbl.Name = "modelLbl";
            this.modelLbl.Size = new System.Drawing.Size(59, 18);
            this.modelLbl.TabIndex = 2;
            this.modelLbl.Text = "Model:";
            // 
            // milesLbl
            // 
            this.milesLbl.AutoSize = true;
            this.milesLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.milesLbl.Location = new System.Drawing.Point(45, 195);
            this.milesLbl.Name = "milesLbl";
            this.milesLbl.Size = new System.Drawing.Size(122, 18);
            this.milesLbl.TabIndex = 3;
            this.milesLbl.Text = "Miles Traveled:";
            // 
            // gasLbl
            // 
            this.gasLbl.AutoSize = true;
            this.gasLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gasLbl.Location = new System.Drawing.Point(42, 236);
            this.gasLbl.Name = "gasLbl";
            this.gasLbl.Size = new System.Drawing.Size(142, 16);
            this.gasLbl.TabIndex = 4;
            this.gasLbl.Text = "Gas Used(gallons):";
            // 
            // outputLbl
            // 
            this.outputLbl.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.outputLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputLbl.Location = new System.Drawing.Point(63, 321);
            this.outputLbl.Name = "outputLbl";
            this.outputLbl.Size = new System.Drawing.Size(279, 107);
            this.outputLbl.TabIndex = 5;
            // 
            // nameTb
            // 
            this.nameTb.Location = new System.Drawing.Point(184, 29);
            this.nameTb.Name = "nameTb";
            this.nameTb.Size = new System.Drawing.Size(158, 20);
            this.nameTb.TabIndex = 6;
            // 
            // makeTb
            // 
            this.makeTb.Location = new System.Drawing.Point(184, 116);
            this.makeTb.Name = "makeTb";
            this.makeTb.Size = new System.Drawing.Size(158, 20);
            this.makeTb.TabIndex = 7;
            // 
            // modelTb
            // 
            this.modelTb.Location = new System.Drawing.Point(184, 157);
            this.modelTb.Name = "modelTb";
            this.modelTb.Size = new System.Drawing.Size(158, 20);
            this.modelTb.TabIndex = 8;
            // 
            // milesTb
            // 
            this.milesTb.Location = new System.Drawing.Point(184, 195);
            this.milesTb.Name = "milesTb";
            this.milesTb.Size = new System.Drawing.Size(158, 20);
            this.milesTb.TabIndex = 9;
            // 
            // gasTb
            // 
            this.gasTb.Location = new System.Drawing.Point(184, 234);
            this.gasTb.Name = "gasTb";
            this.gasTb.Size = new System.Drawing.Size(158, 20);
            this.gasTb.TabIndex = 10;
            // 
            // displayBtn
            // 
            this.displayBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayBtn.Location = new System.Drawing.Point(12, 272);
            this.displayBtn.Name = "displayBtn";
            this.displayBtn.Size = new System.Drawing.Size(110, 33);
            this.displayBtn.TabIndex = 11;
            this.displayBtn.Text = "Display MPG";
            this.displayBtn.UseVisualStyleBackColor = true;
            this.displayBtn.Click += new System.EventHandler(this.displayBtn_Click);
            // 
            // yearLbl
            // 
            this.yearLbl.AutoSize = true;
            this.yearLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearLbl.Location = new System.Drawing.Point(45, 74);
            this.yearLbl.Name = "yearLbl";
            this.yearLbl.Size = new System.Drawing.Size(47, 18);
            this.yearLbl.TabIndex = 12;
            this.yearLbl.Text = "Year:";
            // 
            // yearTb
            // 
            this.yearTb.Location = new System.Drawing.Point(184, 74);
            this.yearTb.Name = "yearTb";
            this.yearTb.Size = new System.Drawing.Size(158, 20);
            this.yearTb.TabIndex = 13;
            // 
            // clearBtn
            // 
            this.clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.Location = new System.Drawing.Point(149, 272);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(110, 33);
            this.clearBtn.TabIndex = 14;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBtn.Location = new System.Drawing.Point(271, 272);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(110, 33);
            this.exitBtn.TabIndex = 15;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(393, 437);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.yearTb);
            this.Controls.Add(this.yearLbl);
            this.Controls.Add(this.displayBtn);
            this.Controls.Add(this.gasTb);
            this.Controls.Add(this.milesTb);
            this.Controls.Add(this.modelTb);
            this.Controls.Add(this.makeTb);
            this.Controls.Add(this.nameTb);
            this.Controls.Add(this.outputLbl);
            this.Controls.Add(this.gasLbl);
            this.Controls.Add(this.milesLbl);
            this.Controls.Add(this.modelLbl);
            this.Controls.Add(this.makeLbl);
            this.Controls.Add(this.nameLbl);
            this.Name = "Form1";
            this.Text = "MPG Calculation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label makeLbl;
        private System.Windows.Forms.Label modelLbl;
        private System.Windows.Forms.Label milesLbl;
        private System.Windows.Forms.Label gasLbl;
        private System.Windows.Forms.Label outputLbl;
        private System.Windows.Forms.TextBox nameTb;
        private System.Windows.Forms.TextBox makeTb;
        private System.Windows.Forms.TextBox modelTb;
        private System.Windows.Forms.TextBox milesTb;
        private System.Windows.Forms.TextBox gasTb;
        private System.Windows.Forms.Button displayBtn;
        private System.Windows.Forms.Label yearLbl;
        private System.Windows.Forms.TextBox yearTb;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button exitBtn;
    }
}

