﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Gunn, Tony
//09/14/2017
//This program will assess price for my paint company.
namespace PainteRusHw6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {

            //declare and assign constant variables
            const int baseSqFt = 115;
            const double laborFee = 20;
            const int laborPerUnit = 8;
            //declare and assign field variables
            double laborHours = 0;
            double paintCost = 0;
            double apc = 0;
            double totalLaborCost = 0;
            double sqFtInput = 0;
            double totalPaintCost = 0;
            
           
            //ngr = number of gallons required.
            double ngr = 0;

            string output = "";

            try
            {
                //parse data from textboxes to correct data type
                sqFtInput = double.Parse(squareFootTb.Text);
                paintCost = double.Parse(paintPriceTb.Text);

                // calc
                ngr = sqFtInput / baseSqFt;
                laborHours = ngr * laborPerUnit;
                paintCost = paintCost * ngr;
                totalLaborCost = laborHours * laborFee;
                

                //Round the calculations
                sqFtInput = Math.Ceiling(sqFtInput);
                paintCost = Math.Floor(paintCost);
                ngr = Math.Ceiling(ngr);


                

                apc = paintCost * ngr;
                totalPaintCost = totalLaborCost + apc;
                //display work

                output = "Gallons of Paint Required: " + ngr.ToString("n0") +
                    "\n Hours of Labor Required: " + laborHours.ToString("n") +
                    "\n Cost of Paint: " + apc.ToString("c") +
                    "\n Labor Fee: " + totalLaborCost.ToString("c") +
                    "\n Total Cost: " + totalPaintCost.ToString("c");

                outputLbl.Text = output;

              

            }
            catch
            {
                MessageBox.Show("Invalid input! Please enter correct format; no blanks.");

            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            //clear data entered from user

            paintPriceTb.Text = "";
            squareFootTb.Text = "";
            outputLbl.Text = "";
            squareFootTb.Focus();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
