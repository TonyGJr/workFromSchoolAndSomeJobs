﻿namespace MathRoundExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numberTb = new System.Windows.Forms.TextBox();
            this.outputLbl = new System.Windows.Forms.Label();
            this.roundBtn = new System.Windows.Forms.Button();
            this.roundFloorBtn = new System.Windows.Forms.Button();
            this.roundCeilingBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(94, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Math Rounding Examples";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(40, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number:";
            // 
            // numberTb
            // 
            this.numberTb.Location = new System.Drawing.Point(124, 122);
            this.numberTb.Name = "numberTb";
            this.numberTb.Size = new System.Drawing.Size(137, 20);
            this.numberTb.TabIndex = 2;
            // 
            // outputLbl
            // 
            this.outputLbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.outputLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLbl.Location = new System.Drawing.Point(95, 189);
            this.outputLbl.Name = "outputLbl";
            this.outputLbl.Size = new System.Drawing.Size(204, 94);
            this.outputLbl.TabIndex = 3;
            // 
            // roundBtn
            // 
            this.roundBtn.Location = new System.Drawing.Point(21, 306);
            this.roundBtn.Name = "roundBtn";
            this.roundBtn.Size = new System.Drawing.Size(102, 48);
            this.roundBtn.TabIndex = 4;
            this.roundBtn.Text = "Round";
            this.roundBtn.UseVisualStyleBackColor = true;
            this.roundBtn.Click += new System.EventHandler(this.roundBtn_Click);
            // 
            // roundFloorBtn
            // 
            this.roundFloorBtn.Location = new System.Drawing.Point(152, 306);
            this.roundFloorBtn.Name = "roundFloorBtn";
            this.roundFloorBtn.Size = new System.Drawing.Size(102, 48);
            this.roundFloorBtn.TabIndex = 5;
            this.roundFloorBtn.Text = "Round Floor";
            this.roundFloorBtn.UseVisualStyleBackColor = true;
            this.roundFloorBtn.Click += new System.EventHandler(this.roundFloorBtn_Click);
            // 
            // roundCeilingBtn
            // 
            this.roundCeilingBtn.Location = new System.Drawing.Point(283, 306);
            this.roundCeilingBtn.Name = "roundCeilingBtn";
            this.roundCeilingBtn.Size = new System.Drawing.Size(102, 48);
            this.roundCeilingBtn.TabIndex = 6;
            this.roundCeilingBtn.Text = "Round Ceiling";
            this.roundCeilingBtn.UseVisualStyleBackColor = true;
            this.roundCeilingBtn.Click += new System.EventHandler(this.roundCeilingBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 388);
            this.Controls.Add(this.roundCeilingBtn);
            this.Controls.Add(this.roundFloorBtn);
            this.Controls.Add(this.roundBtn);
            this.Controls.Add(this.outputLbl);
            this.Controls.Add(this.numberTb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox numberTb;
        private System.Windows.Forms.Label outputLbl;
        private System.Windows.Forms.Button roundBtn;
        private System.Windows.Forms.Button roundFloorBtn;
        private System.Windows.Forms.Button roundCeilingBtn;
    }
}

