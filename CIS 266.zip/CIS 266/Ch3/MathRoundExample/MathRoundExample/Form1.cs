﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MathRoundExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void roundBtn_Click(object sender, EventArgs e)
        {
            // round the value and then display

            double num = double.Parse(numberTb.Text);

            num = Math.Round(num);

            //display the rounded number
            outputLbl.Text = num.ToString();
        }

        private void roundFloorBtn_Click(object sender, EventArgs e)
        {
            // round and then display
            double num = double.Parse(numberTb.Text);

            num = Math.Floor(num);

            //display the rounded number
            outputLbl.Text = num.ToString();
        }

        private void roundCeilingBtn_Click(object sender, EventArgs e)
        {
            // round and then display
            double num = double.Parse(numberTb.Text);

            num = Math.Ceiling(num);

            //display the rounded number
            outputLbl.Text = num.ToString();
        }
    }
}
