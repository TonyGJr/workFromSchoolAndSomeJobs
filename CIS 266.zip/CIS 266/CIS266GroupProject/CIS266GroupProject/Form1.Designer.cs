﻿namespace CIS266GroupProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.roundsLabel = new System.Windows.Forms.Label();
            this.highestNumLabel = new System.Windows.Forms.Label();
            this.correctPictureBox = new System.Windows.Forms.PictureBox();
            this.incorrectPictureBox = new System.Windows.Forms.PictureBox();
            this.roundsTextBox = new System.Windows.Forms.TextBox();
            this.highestNumTextBox = new System.Windows.Forms.TextBox();
            this.num1Label = new System.Windows.Forms.Label();
            this.plusLabel = new System.Windows.Forms.Label();
            this.num2Label = new System.Windows.Forms.Label();
            this.equalLabel = new System.Windows.Forms.Label();
            this.answerTextBox = new System.Windows.Forms.TextBox();
            this.enterButton = new System.Windows.Forms.Button();
            this.startGameButton = new System.Windows.Forms.Button();
            this.correctLabel = new System.Windows.Forms.Label();
            this.incorrectLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.correctOutputLabel = new System.Windows.Forms.Label();
            this.incorrectOutputLabel = new System.Windows.Forms.Label();
            this.totalOutputLabel = new System.Windows.Forms.Label();
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.correctPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.incorrectPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // roundsLabel
            // 
            this.roundsLabel.AutoSize = true;
            this.roundsLabel.Location = new System.Drawing.Point(263, 186);
            this.roundsLabel.Name = "roundsLabel";
            this.roundsLabel.Size = new System.Drawing.Size(296, 20);
            this.roundsLabel.TabIndex = 0;
            this.roundsLabel.Text = "How many rounds would you like to play?";
            // 
            // highestNumLabel
            // 
            this.highestNumLabel.AutoSize = true;
            this.highestNumLabel.Location = new System.Drawing.Point(263, 240);
            this.highestNumLabel.Name = "highestNumLabel";
            this.highestNumLabel.Size = new System.Drawing.Size(361, 20);
            this.highestNumLabel.TabIndex = 1;
            this.highestNumLabel.Text = "What is the highest number you would like to use?";
            // 
            // correctPictureBox
            // 
            this.correctPictureBox.Image = global::CIS266GroupProject.Properties.Resources.correct2;
            this.correctPictureBox.Location = new System.Drawing.Point(45, 143);
            this.correctPictureBox.Name = "correctPictureBox";
            this.correctPictureBox.Size = new System.Drawing.Size(154, 132);
            this.correctPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.correctPictureBox.TabIndex = 2;
            this.correctPictureBox.TabStop = false;
            // 
            // incorrectPictureBox
            // 
            this.incorrectPictureBox.Image = global::CIS266GroupProject.Properties.Resources.incorrect;
            this.incorrectPictureBox.Location = new System.Drawing.Point(850, 124);
            this.incorrectPictureBox.Name = "incorrectPictureBox";
            this.incorrectPictureBox.Size = new System.Drawing.Size(154, 132);
            this.incorrectPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.incorrectPictureBox.TabIndex = 3;
            this.incorrectPictureBox.TabStop = false;
            // 
            // roundsTextBox
            // 
            this.roundsTextBox.Location = new System.Drawing.Point(648, 180);
            this.roundsTextBox.Name = "roundsTextBox";
            this.roundsTextBox.Size = new System.Drawing.Size(141, 26);
            this.roundsTextBox.TabIndex = 4;
            // 
            // highestNumTextBox
            // 
            this.highestNumTextBox.Location = new System.Drawing.Point(648, 234);
            this.highestNumTextBox.Name = "highestNumTextBox";
            this.highestNumTextBox.Size = new System.Drawing.Size(141, 26);
            this.highestNumTextBox.TabIndex = 5;
            // 
            // num1Label
            // 
            this.num1Label.BackColor = System.Drawing.SystemColors.Info;
            this.num1Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.num1Label.Font = new System.Drawing.Font("Comic Sans MS", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num1Label.Location = new System.Drawing.Point(211, 286);
            this.num1Label.Name = "num1Label";
            this.num1Label.Size = new System.Drawing.Size(122, 98);
            this.num1Label.TabIndex = 6;
            this.num1Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // plusLabel
            // 
            this.plusLabel.BackColor = System.Drawing.SystemColors.Info;
            this.plusLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.plusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plusLabel.Location = new System.Drawing.Point(348, 286);
            this.plusLabel.Name = "plusLabel";
            this.plusLabel.Size = new System.Drawing.Size(104, 98);
            this.plusLabel.TabIndex = 7;
            this.plusLabel.Text = "+";
            // 
            // num2Label
            // 
            this.num2Label.BackColor = System.Drawing.SystemColors.Info;
            this.num2Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.num2Label.Font = new System.Drawing.Font("Comic Sans MS", 36F, System.Drawing.FontStyle.Bold);
            this.num2Label.Location = new System.Drawing.Point(468, 286);
            this.num2Label.Name = "num2Label";
            this.num2Label.Size = new System.Drawing.Size(122, 98);
            this.num2Label.TabIndex = 8;
            // 
            // equalLabel
            // 
            this.equalLabel.BackColor = System.Drawing.SystemColors.Info;
            this.equalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.equalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.equalLabel.Location = new System.Drawing.Point(616, 286);
            this.equalLabel.Name = "equalLabel";
            this.equalLabel.Size = new System.Drawing.Size(104, 98);
            this.equalLabel.TabIndex = 9;
            this.equalLabel.Text = "=";
            // 
            // answerTextBox
            // 
            this.answerTextBox.Location = new System.Drawing.Point(743, 325);
            this.answerTextBox.Name = "answerTextBox";
            this.answerTextBox.Size = new System.Drawing.Size(156, 26);
            this.answerTextBox.TabIndex = 10;
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(389, 401);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(142, 45);
            this.enterButton.TabIndex = 11;
            this.enterButton.Text = "Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // startGameButton
            // 
            this.startGameButton.Location = new System.Drawing.Point(222, 401);
            this.startGameButton.Name = "startGameButton";
            this.startGameButton.Size = new System.Drawing.Size(142, 45);
            this.startGameButton.TabIndex = 12;
            this.startGameButton.Text = "Start Game";
            this.startGameButton.UseVisualStyleBackColor = true;
            this.startGameButton.Click += new System.EventHandler(this.startGameButton_Click);
            // 
            // correctLabel
            // 
            this.correctLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.correctLabel.Location = new System.Drawing.Point(177, 495);
            this.correctLabel.Name = "correctLabel";
            this.correctLabel.Size = new System.Drawing.Size(174, 42);
            this.correctLabel.TabIndex = 13;
            this.correctLabel.Text = "Correct :";
            // 
            // incorrectLabel
            // 
            this.incorrectLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.incorrectLabel.Location = new System.Drawing.Point(339, 495);
            this.incorrectLabel.Name = "incorrectLabel";
            this.incorrectLabel.Size = new System.Drawing.Size(192, 42);
            this.incorrectLabel.TabIndex = 14;
            this.incorrectLabel.Text = "Incorrect :";
            // 
            // totalLabel
            // 
            this.totalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLabel.Location = new System.Drawing.Point(529, 495);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(126, 42);
            this.totalLabel.TabIndex = 15;
            this.totalLabel.Text = "Total :";
            // 
            // correctOutputLabel
            // 
            this.correctOutputLabel.BackColor = System.Drawing.SystemColors.Info;
            this.correctOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.correctOutputLabel.Font = new System.Drawing.Font("Comic Sans MS", 36F, System.Drawing.FontStyle.Bold);
            this.correctOutputLabel.Location = new System.Drawing.Point(211, 553);
            this.correctOutputLabel.Name = "correctOutputLabel";
            this.correctOutputLabel.Size = new System.Drawing.Size(122, 98);
            this.correctOutputLabel.TabIndex = 16;
            // 
            // incorrectOutputLabel
            // 
            this.incorrectOutputLabel.BackColor = System.Drawing.SystemColors.Info;
            this.incorrectOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.incorrectOutputLabel.Font = new System.Drawing.Font("Comic Sans MS", 36F, System.Drawing.FontStyle.Bold);
            this.incorrectOutputLabel.Location = new System.Drawing.Point(348, 553);
            this.incorrectOutputLabel.Name = "incorrectOutputLabel";
            this.incorrectOutputLabel.Size = new System.Drawing.Size(122, 98);
            this.incorrectOutputLabel.TabIndex = 17;
            // 
            // totalOutputLabel
            // 
            this.totalOutputLabel.BackColor = System.Drawing.SystemColors.Info;
            this.totalOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalOutputLabel.Font = new System.Drawing.Font("Comic Sans MS", 36F, System.Drawing.FontStyle.Bold);
            this.totalOutputLabel.Location = new System.Drawing.Point(513, 553);
            this.totalOutputLabel.Name = "totalOutputLabel";
            this.totalOutputLabel.Size = new System.Drawing.Size(122, 98);
            this.totalOutputLabel.TabIndex = 18;
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeLabel.Location = new System.Drawing.Point(138, 92);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(851, 29);
            this.welcomeLabel.TabIndex = 19;
            this.welcomeLabel.Text = "Welcome to Math Games! Please Enter the following information to play.";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(263, 143);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(149, 20);
            this.nameLabel.TabIndex = 20;
            this.nameLabel.Text = "What is your name?";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(459, 143);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(196, 26);
            this.nameTextBox.TabIndex = 21;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(561, 401);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(142, 45);
            this.exitButton.TabIndex = 22;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CIS266GroupProject.Properties.Resources.math;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1039, 675);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.welcomeLabel);
            this.Controls.Add(this.totalOutputLabel);
            this.Controls.Add(this.incorrectOutputLabel);
            this.Controls.Add(this.correctOutputLabel);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.incorrectLabel);
            this.Controls.Add(this.correctLabel);
            this.Controls.Add(this.startGameButton);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.answerTextBox);
            this.Controls.Add(this.equalLabel);
            this.Controls.Add(this.num2Label);
            this.Controls.Add(this.plusLabel);
            this.Controls.Add(this.num1Label);
            this.Controls.Add(this.highestNumTextBox);
            this.Controls.Add(this.roundsTextBox);
            this.Controls.Add(this.incorrectPictureBox);
            this.Controls.Add(this.correctPictureBox);
            this.Controls.Add(this.highestNumLabel);
            this.Controls.Add(this.roundsLabel);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Math Games !";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.correctPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.incorrectPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label roundsLabel;
        private System.Windows.Forms.Label highestNumLabel;
        private System.Windows.Forms.PictureBox correctPictureBox;
        private System.Windows.Forms.PictureBox incorrectPictureBox;
        private System.Windows.Forms.TextBox roundsTextBox;
        private System.Windows.Forms.TextBox highestNumTextBox;
        private System.Windows.Forms.Label num1Label;
        private System.Windows.Forms.Label plusLabel;
        private System.Windows.Forms.Label num2Label;
        private System.Windows.Forms.Label equalLabel;
        private System.Windows.Forms.TextBox answerTextBox;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Button startGameButton;
        private System.Windows.Forms.Label correctLabel;
        private System.Windows.Forms.Label incorrectLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label correctOutputLabel;
        private System.Windows.Forms.Label incorrectOutputLabel;
        private System.Windows.Forms.Label totalOutputLabel;
        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Button exitButton;
    }
}

