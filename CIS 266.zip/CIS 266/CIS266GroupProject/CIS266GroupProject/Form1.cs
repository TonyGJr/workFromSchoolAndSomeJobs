﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* Juwan Carey and Tony Gunn Jr
 * CIS 266-901
 * Math Game Group Project 
 * 10/17/17
 */

namespace CIS266GroupProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
            //Set visiblity properties for the intial start of the game

            num1Label.Visible = false;
            num2Label.Visible = false;
            plusLabel.Visible = false;
            equalLabel.Visible = false;
            answerTextBox.Visible = false;
            enterButton.Visible = false;

            correctLabel.Visible = false;
            correctOutputLabel.Visible = false;
            correctLabel.Visible = false;
            totalLabel.Visible = false;
            incorrectOutputLabel.Visible = false;
            incorrectLabel.Visible = false;
            totalOutputLabel.Visible = false;
        

            roundsLabel.Visible = true;
            highestNumLabel.Visible = true;
            nameLabel.Visible = true;
            roundsTextBox.Visible = true;
            highestNumTextBox.Visible = true;
            nameTextBox.Visible = true;
            startGameButton.Visible = true;

            correctPictureBox.Visible = false;
            incorrectPictureBox.Visible = false;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // Display meesage box before the form loads welcoming users to the game

            MessageBox.Show("Are you ready to play Math Games !!");
        }

        // Insantiate a new random variable called rand

        Random rand = new Random();

        // Declare field variables
        int totalRounds = 0;
        int highestNum = 0;
        int currentRound = 0;
        int correct = 0;
        int incorrect = 0;
        int num1 = 0;
        int num2 = 0;
        int sum = 0;
        int answer = 0;

        decimal avg = 0m;

        string name = "";


        private void enterButton_Click(object sender, EventArgs e)
        {
            // Math Calculations
            sum = num1 + num2;
            // Calc the test score
            avg = correct / totalRounds;


            // Try Parse statement to convert answer input from user and
            // convert to the answer int variable

            if (int.TryParse(answerTextBox.Text, out answer))
            {
                // checks to see if user's answer is equal to the correct sum
                // if so it will add a point to the correct varriable and
                // also display the correct picture box

                if (answer == sum) 
                {
                    correct = correct + 1;
                    correctPictureBox.Visible = true;
                    incorrectPictureBox.Visible = false;
                    answerTextBox.Text = "";
                    answerTextBox.Focus();
                }

                // If answer is inccorect the wrong picture box will display
                // and it will add a point to the incorrect variable

                else
                {
                    incorrect = incorrect + 1;
                    incorrectPictureBox.Visible = true;
                    correctPictureBox.Visible = false;
                    answerTextBox.Text = "";
                    answerTextBox.Focus();
                }
            }

            // Code will execute if tryParse validation fails 
            // and will redirect user to enter a valid format in textBox

            else
            {
                MessageBox.Show("Please enter a valid answer format.");
                answerTextBox.Text = "";
                answerTextBox.Focus();
            }

            // Assign random numbers to each variable between 1 and
            // the highest number selected by the user

            num1 = rand.Next(highestNum) + 1;
            num2 = rand.Next(highestNum) + 1;

            // Display the random numbers to their respective labels

            num1Label.Text = num1.ToString();
            num2Label.Text = num2.ToString();

            // Will add 1 to the current round variable after each equation is completed

            currentRound = currentRound + 1;

            
            // Assign the text properties to their respective values

            correctOutputLabel.Text = correct.ToString();
            incorrectOutputLabel.Text = incorrect.ToString();
            totalOutputLabel.Text = currentRound.ToString();
            name = nameTextBox.Text;



            // Will end the game when the current round equals the amount
            // of rounds the user selected and resets to original form.
            if (currentRound >= totalRounds)
            {
                MessageBox.Show(name + " got " + correct + " correct and " + incorrect + " incorrect. You played " + totalRounds + " rounds." + " " + avg);
                num1Label.Visible = false;
                num2Label.Visible = false;
                plusLabel.Visible = false;
                equalLabel.Visible = false;
                answerTextBox.Visible = false;
                enterButton.Visible = false;

                correctLabel.Visible = false;
                correctOutputLabel.Visible = false;
                incorrectLabel.Visible = false;
                incorrectOutputLabel.Visible = false;
                totalLabel.Visible = false;
                totalOutputLabel.Visible = false;

                roundsLabel.Visible = true;
                nameLabel.Visible = true;
                highestNumLabel.Visible = true;
                roundsTextBox.Visible = true;
                nameTextBox.Visible = true;
                highestNumTextBox.Visible = true;
                startGameButton.Visible = true;

                correctPictureBox.Visible = false;
                incorrectPictureBox.Visible = false;

                roundsTextBox.Text = "";
                highestNumTextBox.Text = "";
                roundsTextBox.Focus();
            }
        }

        private void startGameButton_Click(object sender, EventArgs e)
        {
            // Validate & Parse the rounds TextBox and the highest Num TextBox 

            if (int.TryParse(roundsTextBox.Text, out totalRounds))
            {
                if (int.TryParse(highestNumTextBox.Text, out highestNum))
                {
                    // Validate that the user entered in number
                    //  greater than 0

                    if (totalRounds > 0)
                    {
                        //Set Visibility properties

                        num1Label.Visible = true;
                        num2Label.Visible = true;
                        plusLabel.Visible = true;
                        equalLabel.Visible = true;
                        answerTextBox.Visible = true;
                        enterButton.Visible = true;

                        correctLabel.Visible = true;
                        correctOutputLabel.Visible = true;
                        incorrectLabel.Visible = true;
                        incorrectOutputLabel.Visible = true;
                        totalLabel.Visible = true;
                        totalOutputLabel.Visible = true;

                        roundsLabel.Visible = false;
                        highestNumLabel.Visible = false;
                        roundsTextBox.Visible = false;
                        highestNumTextBox.Visible = false;
                        startGameButton.Visible = false;

                        // set int variables to 0 for start of the game

                        currentRound = 0;
                        correct = 0;
                        incorrect = 0;

                        // Assign num variables to random numbers b/t 1
                        // and the highest number selected by user

                        num1 = rand.Next(highestNum) + 1;
                        num2 = rand.Next(highestNum) + 1;

                        // Set num labels to the random variables

                        num1Label.Text = num1.ToString();
                        num2Label.Text = num2.ToString();


                        correctOutputLabel.Text = "0";
                        incorrectOutputLabel.Text = "0";
                        totalOutputLabel.Text = "0";
                        answerTextBox.Text = "";

                    }
                    // Else statements for failed Validations

                    else
                        MessageBox.Show("Invalid amount of rounds to play, cannot be below 1.");
                }
                else
                    MessageBox.Show("Invalid highest number to use.");
            }
            else
                MessageBox.Show("Invalid amount of rounds to play.");

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the Application
            this.Close();
        }
    }
}
    

