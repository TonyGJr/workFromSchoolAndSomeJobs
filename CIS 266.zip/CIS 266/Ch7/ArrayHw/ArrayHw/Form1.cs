﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* Gunn, Tony
 * 11/07/2017
 * This program will display names from an array.
 * */
namespace ArrayHw
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            // set a string array and assign five names
            string[] nameArray = { "Tony Gunn " + "\n" + "Juwan Carey" + "\n" + "Peter Gunns" + "\n" + "Ant Butler" + "\n" + "Uri Svali" };
          
            // foreach loop and display
            foreach (string output in nameArray)
                {
                outputLbl.Text = output;
                }
            
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            //clear label text
            outputLbl.Text = "";
        }
    }
}
