﻿namespace BubbleSortExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nonSortedLbl = new System.Windows.Forms.Label();
            this.nonSortedBtn = new System.Windows.Forms.Button();
            this.sortedBtn = new System.Windows.Forms.Button();
            this.sortedLbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.clearBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(78, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Non-Sorted:";
            // 
            // nonSortedLbl
            // 
            this.nonSortedLbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.nonSortedLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.nonSortedLbl.Location = new System.Drawing.Point(31, 75);
            this.nonSortedLbl.Name = "nonSortedLbl";
            this.nonSortedLbl.Size = new System.Drawing.Size(181, 182);
            this.nonSortedLbl.TabIndex = 1;
            // 
            // nonSortedBtn
            // 
            this.nonSortedBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nonSortedBtn.Location = new System.Drawing.Point(62, 287);
            this.nonSortedBtn.Name = "nonSortedBtn";
            this.nonSortedBtn.Size = new System.Drawing.Size(113, 64);
            this.nonSortedBtn.TabIndex = 2;
            this.nonSortedBtn.Text = "Non-Sorted Array";
            this.nonSortedBtn.UseVisualStyleBackColor = true;
            this.nonSortedBtn.Click += new System.EventHandler(this.nonSortedBtn_Click);
            // 
            // sortedBtn
            // 
            this.sortedBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sortedBtn.Location = new System.Drawing.Point(367, 287);
            this.sortedBtn.Name = "sortedBtn";
            this.sortedBtn.Size = new System.Drawing.Size(110, 64);
            this.sortedBtn.TabIndex = 5;
            this.sortedBtn.Text = "Sorted Array";
            this.sortedBtn.UseVisualStyleBackColor = true;
            this.sortedBtn.Click += new System.EventHandler(this.sortedBtn_Click);
            // 
            // sortedLbl
            // 
            this.sortedLbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.sortedLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.sortedLbl.Location = new System.Drawing.Point(327, 75);
            this.sortedLbl.Name = "sortedLbl";
            this.sortedLbl.Size = new System.Drawing.Size(181, 182);
            this.sortedLbl.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(374, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Sorted:";
            // 
            // clearBtn
            // 
            this.clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.Location = new System.Drawing.Point(198, 397);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(121, 46);
            this.clearBtn.TabIndex = 6;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 483);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.sortedBtn);
            this.Controls.Add(this.sortedLbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.nonSortedBtn);
            this.Controls.Add(this.nonSortedLbl);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Bubble Sort Example";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label nonSortedLbl;
        private System.Windows.Forms.Button nonSortedBtn;
        private System.Windows.Forms.Button sortedBtn;
        private System.Windows.Forms.Label sortedLbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button clearBtn;
    }
}

