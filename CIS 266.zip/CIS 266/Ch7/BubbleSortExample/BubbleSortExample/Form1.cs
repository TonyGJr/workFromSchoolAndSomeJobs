﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*Gunn, Tony
 11/16/2017
 This program will traverse through an array and order the elements (int) in ascending order.
 */

namespace BubbleSortExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //field level variables
        int[] numbers = { 12, 57, 46, 98, 18, 6, 63, 81, 27, 90, 32};

        private void nonSortedBtn_Click(object sender, EventArgs e)
        {
            // Display the Non-sorted array values

            string nonSorted = "";

            foreach(int element in numbers)
            {
                nonSorted = nonSorted + element + "\n";
            }

            // Display into the non-sorted label
            nonSortedLbl.Text = nonSorted.ToString();
        }

        private void sortedBtn_Click(object sender, EventArgs e)
        {
            // Bubble sort this array to place the values in ascending order

            int temp = 0;
            int count = 0;

            string sorted = "";

            //loops

            for (int x = 0; x < numbers.Length; x++)
            {  
                    for(int z = 0; z< numbers.Length - 1 - x; z++)
                    {
                        if(numbers[z] > numbers[z + 1])
                        {
                        temp = numbers[z];
                        numbers[z] = numbers[z + 1];
                        numbers[z + 1] = temp;
                        }
                        count++;
                   
                    }
            }
            // Display into the sorted label
            foreach(int element in numbers)
            {
                sorted = sorted + element + "\n";
            }

            sortedLbl.Text = sorted.ToString();

            MessageBox.Show("The count value is: " + count.ToString());
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            sortedLbl.Text = "";
            nonSortedLbl.Text = "";
        }
    }
}
