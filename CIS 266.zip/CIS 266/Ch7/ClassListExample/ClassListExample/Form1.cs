﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Carey, Juwan
//11/28/2017
//This progam will make list

namespace ClassListExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        // Field Data Structure

        List<string> names = new List<string>() { "Tom", "Alice", "Lewis", "Karen" };


        private void showButton_Click(object sender, EventArgs e)
        {
            // display the list into the display label

            // Call method to display list

            ShowDisplay();
        }

        private void ShowDisplay()
        {
            // traverse the list displaying each element

            string output = "";

            foreach (string element in names)
            {

                output = output + element + "\n";
            }

            displayLabel.Text = output;
        }

        private void sortButton_Click(object sender, EventArgs e)
        {
            // Sort the array

            names.Sort();

            // call display method

            ShowDisplay();

           
        }

        private void addNameButton_Click(object sender, EventArgs e)
        {
            // Add the name into the List

            string addName = nameTextBox.Text;

            names.Add(addName);

            MessageBox.Show(addName + " will be added to the list");

            // call the show display method

            ShowDisplay();

            // clear the textbox 

            nameTextBox.Text = "";

            // reset the focus

            nameTextBox.Focus();
        }

        private void deleteNameButton_Click(object sender, EventArgs e)
        {
            // store the name user would like to delete

            string deleteName = deleteNameTextBox.Text;

            names.Remove(deleteName);

            // Call display method

            ShowDisplay();

            // clear text box and reset focus

            deleteNameTextBox.Text = "";
            deleteNameTextBox.Focus();
        }

        private void searchNameButton_Click(object sender, EventArgs e)
        {
            string searchName = searchNametTextBox.Text;
           
        }


        private void countButton_Click(object sender, EventArgs e)
        {
           // MessageBox.Show("The total amount of names are: " + names.Length);
        }

       
    }
}
