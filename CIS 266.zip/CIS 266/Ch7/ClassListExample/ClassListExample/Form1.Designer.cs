﻿namespace ClassListExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.displayLabel = new System.Windows.Forms.Label();
            this.showButton = new System.Windows.Forms.Button();
            this.sortButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.addNameButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.deleteNameTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.searchNametTextBox = new System.Windows.Forms.TextBox();
            this.deleteNameButton = new System.Windows.Forms.Button();
            this.searchNameButton = new System.Windows.Forms.Button();
            this.countButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(195, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "List Examples";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(56, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Display List";
            // 
            // displayLabel
            // 
            this.displayLabel.BackColor = System.Drawing.Color.Lime;
            this.displayLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayLabel.Location = new System.Drawing.Point(26, 92);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(142, 175);
            this.displayLabel.TabIndex = 2;
            // 
            // showButton
            // 
            this.showButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showButton.Location = new System.Drawing.Point(26, 313);
            this.showButton.Name = "showButton";
            this.showButton.Size = new System.Drawing.Size(95, 33);
            this.showButton.TabIndex = 3;
            this.showButton.Text = "Show List";
            this.showButton.UseVisualStyleBackColor = true;
            this.showButton.Click += new System.EventHandler(this.showButton_Click);
            // 
            // sortButton
            // 
            this.sortButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sortButton.Location = new System.Drawing.Point(153, 315);
            this.sortButton.Name = "sortButton";
            this.sortButton.Size = new System.Drawing.Size(95, 31);
            this.sortButton.TabIndex = 4;
            this.sortButton.Text = "Sort List";
            this.sortButton.UseVisualStyleBackColor = true;
            this.sortButton.Click += new System.EventHandler(this.sortButton_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(224, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(203, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Enter a name to add to the List";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(262, 112);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 6;
            // 
            // addNameButton
            // 
            this.addNameButton.BackColor = System.Drawing.Color.Chartreuse;
            this.addNameButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addNameButton.Location = new System.Drawing.Point(474, 110);
            this.addNameButton.Name = "addNameButton";
            this.addNameButton.Size = new System.Drawing.Size(75, 23);
            this.addNameButton.TabIndex = 7;
            this.addNameButton.Text = "Add";
            this.addNameButton.UseVisualStyleBackColor = false;
            this.addNameButton.Click += new System.EventHandler(this.addNameButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(224, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(215, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Enter a name to delete from the List";
            // 
            // deleteNameTextBox
            // 
            this.deleteNameTextBox.Location = new System.Drawing.Point(262, 173);
            this.deleteNameTextBox.Name = "deleteNameTextBox";
            this.deleteNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.deleteNameTextBox.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(224, 216);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(189, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Enter a name to search the List";
            // 
            // searchNametTextBox
            // 
            this.searchNametTextBox.Location = new System.Drawing.Point(262, 252);
            this.searchNametTextBox.Name = "searchNametTextBox";
            this.searchNametTextBox.Size = new System.Drawing.Size(100, 20);
            this.searchNametTextBox.TabIndex = 11;
            // 
            // deleteNameButton
            // 
            this.deleteNameButton.BackColor = System.Drawing.Color.Red;
            this.deleteNameButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteNameButton.Location = new System.Drawing.Point(474, 173);
            this.deleteNameButton.Name = "deleteNameButton";
            this.deleteNameButton.Size = new System.Drawing.Size(75, 23);
            this.deleteNameButton.TabIndex = 12;
            this.deleteNameButton.Text = "Delete";
            this.deleteNameButton.UseVisualStyleBackColor = false;
            this.deleteNameButton.Click += new System.EventHandler(this.deleteNameButton_Click);
            // 
            // searchNameButton
            // 
            this.searchNameButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.searchNameButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchNameButton.Location = new System.Drawing.Point(474, 249);
            this.searchNameButton.Name = "searchNameButton";
            this.searchNameButton.Size = new System.Drawing.Size(75, 23);
            this.searchNameButton.TabIndex = 13;
            this.searchNameButton.Text = "Search";
            this.searchNameButton.UseVisualStyleBackColor = false;
            this.searchNameButton.Click += new System.EventHandler(this.searchNameButton_Click);
            // 
            // countButton
            // 
            this.countButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.countButton.Location = new System.Drawing.Point(294, 315);
            this.countButton.Margin = new System.Windows.Forms.Padding(2);
            this.countButton.Name = "countButton";
            this.countButton.Size = new System.Drawing.Size(79, 32);
            this.countButton.TabIndex = 14;
            this.countButton.Text = "Count List";
            this.countButton.UseVisualStyleBackColor = true;
            this.countButton.Click += new System.EventHandler(this.countButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 367);
            this.Controls.Add(this.countButton);
            this.Controls.Add(this.searchNameButton);
            this.Controls.Add(this.deleteNameButton);
            this.Controls.Add(this.searchNametTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.deleteNameTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.addNameButton);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.sortButton);
            this.Controls.Add(this.showButton);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "ListExamples";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.Button showButton;
        private System.Windows.Forms.Button sortButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Button addNameButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox deleteNameTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox searchNametTextBox;
        private System.Windows.Forms.Button deleteNameButton;
        private System.Windows.Forms.Button searchNameButton;
        private System.Windows.Forms.Button countButton;
    }
}

