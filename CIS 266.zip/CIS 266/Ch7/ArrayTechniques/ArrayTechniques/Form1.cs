﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 Gunn, Tony
 11/13/2017
 This program will pass arrays into and from methods
     */
namespace ArrayTechniques
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Declare field arrays to use in the examples

        string[] names = { "Tim", "Frank", "Tony", "Poss", "Ed" };
        int[] array2 = { 10, 20, 30, 40, 50 };

        private void sumArray1Btn_Click(object sender, EventArgs e)
        {
            double total = 0;

            // Display the array in label 1

            // call a method to display 

            DisplayIntArray();

            // sum the array elements

            foreach (int element in array2)
            {
                total = total + element;
            }

            displayLbl1.Text += "\n The sum of the array is:  " + total.ToString("n");
        }
        private void DisplayIntArray()
        {
            string output = "";

            foreach (int element in array2)
            {
                output = output + element + "\n";
            }

            displayLbl1.Text = "Array 2 values are:  \n\n" + output;
        }

        private void averageArrayBtn_Click(object sender, EventArgs e)
        {
            double total = 0;
            double average = 0;

            // calc the average of the array

            // Display the data first

            DisplayIntArray();

            // sum the array for total

            foreach (int element in array2)
            {
                total = total + element;
            }


            //Calc average

            average = total / array2.Length;

            // display the average in label

            displayLbl1.Text += "\nThe Average of the array is: " + average.ToString("n");
        }

        private void passArrayBtn_Click(object sender, EventArgs e)
        {
            string output = "";
            string output2 = "";

            // create a local array to pass to another method

            int[] array1 = { 20, 30, 40, 50, 100 };

            // Display this in the label 1

            foreach (int element in array1)
            {
                output = output + element + "\n";
            }

            // Display into the label
            displayLbl1.Text = output.ToString();

            // pass array 1 to a method
            // ALL arrays pass by ref
            // therefore any changes made in the method the array 1
            // was pass to, will be changed in the arguement method!

            DoubleArrayValue(array1);


            // Show the new values of array 1 after they were changed
            // in the DoubleArrayValue method from passing the array
            // by ref

            foreach (int elements in array1)
            {
                output2 = output2 + elements + "\n";
            }

            displayLbl1.Text += "\n\n" + output2;
        }

        private void DoubleArrayValue(int[] theArray)
        {
            string output = "";


            for (int x = 0; x < theArray.Length; x++)
            {
                theArray[x] = theArray[x] * 2;
            }

            // Display array into label 2

            foreach (int elements in theArray)
            {
                output = output + elements + "\n";
            }

            // Display into label 2
            displayLbl2.Text = output;
        }

        private void highestNumBtn_Click(object sender, EventArgs e)
        {
            string output = "";
            double highestNumber = 0;

            highestNumber = DisplayHighest(array2);


            output = displayLbl1.Text = highestNumber.ToString("n");

        }

        private int DisplayHighest(int[] theArray2)
        {

            // Variable to hold highest numbe in array

            int highest = 0;

            // Traverse the array and assign the highest element
            // to the to the highest variable

            foreach (int elements in theArray2)
            {
                if (elements > highest)
                {
                    highest = elements;
                }
            }

            // return the highest variable to the method
            return highest;
        }

        private void lowestBtn_Click(object sender, EventArgs e)
        {
            string output = "";
            double lowestNumber = 0;

            lowestNumber = DisplayLowest(array2);


            output = displayLbl1.Text = lowestNumber.ToString("n");
        }

        private int DisplayLowest(int[] theArray2)
        {

            int lowest = theArray2[0];

            for (int index = 1; index < theArray2.Length; index++)
            {
                if (theArray2[index] < lowest)
                {
                    lowest = theArray2[index];
                }
            }

            // return the lowest variable to the method
            return lowest;
            
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            // clear the output labels

            displayLbl1.Text = "";
            displayLbl2.Text = "";
        }
    }
}
