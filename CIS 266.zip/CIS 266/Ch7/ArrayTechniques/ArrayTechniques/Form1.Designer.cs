﻿namespace ArrayTechniques
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayLbl1 = new System.Windows.Forms.Label();
            this.displayLbl2 = new System.Windows.Forms.Label();
            this.sumArray1Btn = new System.Windows.Forms.Button();
            this.averageArrayBtn = new System.Windows.Forms.Button();
            this.passArrayBtn = new System.Windows.Forms.Button();
            this.highestNumBtn = new System.Windows.Forms.Button();
            this.lowestBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // displayLbl1
            // 
            this.displayLbl1.BackColor = System.Drawing.Color.Coral;
            this.displayLbl1.Location = new System.Drawing.Point(12, 55);
            this.displayLbl1.Name = "displayLbl1";
            this.displayLbl1.Size = new System.Drawing.Size(236, 239);
            this.displayLbl1.TabIndex = 0;
            // 
            // displayLbl2
            // 
            this.displayLbl2.BackColor = System.Drawing.Color.Coral;
            this.displayLbl2.Location = new System.Drawing.Point(318, 55);
            this.displayLbl2.Name = "displayLbl2";
            this.displayLbl2.Size = new System.Drawing.Size(236, 239);
            this.displayLbl2.TabIndex = 1;
            // 
            // sumArray1Btn
            // 
            this.sumArray1Btn.Location = new System.Drawing.Point(15, 361);
            this.sumArray1Btn.Name = "sumArray1Btn";
            this.sumArray1Btn.Size = new System.Drawing.Size(98, 56);
            this.sumArray1Btn.TabIndex = 2;
            this.sumArray1Btn.Text = "Sum the Array";
            this.sumArray1Btn.UseVisualStyleBackColor = true;
            this.sumArray1Btn.Click += new System.EventHandler(this.sumArray1Btn_Click);
            // 
            // averageArrayBtn
            // 
            this.averageArrayBtn.Location = new System.Drawing.Point(119, 361);
            this.averageArrayBtn.Name = "averageArrayBtn";
            this.averageArrayBtn.Size = new System.Drawing.Size(98, 56);
            this.averageArrayBtn.TabIndex = 3;
            this.averageArrayBtn.Text = "Average Array";
            this.averageArrayBtn.UseVisualStyleBackColor = true;
            this.averageArrayBtn.Click += new System.EventHandler(this.averageArrayBtn_Click);
            // 
            // passArrayBtn
            // 
            this.passArrayBtn.Location = new System.Drawing.Point(223, 361);
            this.passArrayBtn.Name = "passArrayBtn";
            this.passArrayBtn.Size = new System.Drawing.Size(98, 56);
            this.passArrayBtn.TabIndex = 4;
            this.passArrayBtn.Text = "Pass the Array";
            this.passArrayBtn.UseVisualStyleBackColor = true;
            this.passArrayBtn.Click += new System.EventHandler(this.passArrayBtn_Click);
            // 
            // highestNumBtn
            // 
            this.highestNumBtn.Location = new System.Drawing.Point(327, 361);
            this.highestNumBtn.Name = "highestNumBtn";
            this.highestNumBtn.Size = new System.Drawing.Size(98, 56);
            this.highestNumBtn.TabIndex = 5;
            this.highestNumBtn.Text = "Highest Number";
            this.highestNumBtn.UseVisualStyleBackColor = true;
            this.highestNumBtn.Click += new System.EventHandler(this.highestNumBtn_Click);
            // 
            // lowestBtn
            // 
            this.lowestBtn.Location = new System.Drawing.Point(431, 361);
            this.lowestBtn.Name = "lowestBtn";
            this.lowestBtn.Size = new System.Drawing.Size(98, 56);
            this.lowestBtn.TabIndex = 6;
            this.lowestBtn.Text = "Lowest Number";
            this.lowestBtn.UseVisualStyleBackColor = true;
            this.lowestBtn.Click += new System.EventHandler(this.lowestBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(223, 434);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(98, 56);
            this.clearBtn.TabIndex = 7;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Display Label 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(385, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Display Label 2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 502);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.lowestBtn);
            this.Controls.Add(this.highestNumBtn);
            this.Controls.Add(this.passArrayBtn);
            this.Controls.Add(this.averageArrayBtn);
            this.Controls.Add(this.sumArray1Btn);
            this.Controls.Add(this.displayLbl2);
            this.Controls.Add(this.displayLbl1);
            this.Name = "Form1";
            this.Text = "Array Techniques";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label displayLbl1;
        private System.Windows.Forms.Label displayLbl2;
        private System.Windows.Forms.Button sumArray1Btn;
        private System.Windows.Forms.Button averageArrayBtn;
        private System.Windows.Forms.Button passArrayBtn;
        private System.Windows.Forms.Button highestNumBtn;
        private System.Windows.Forms.Button lowestBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

