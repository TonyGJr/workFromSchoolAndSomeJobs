﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Tony Gunn Jr.
//08/31/2017
//This program shows and hides Orion constellation
namespace OrionHW2
{
    public partial class orionConstellation : Form
    {
        public orionConstellation()
        {
            InitializeComponent();
        }

        private void showStarsBtn_Click(object sender, EventArgs e)
        {
            betelgeuseLbl.Visible = true;
            alrilamLbl.Visible = true;
            alritakLbl.Visible = true;
            meissaLbl.Visible = true;
            mirtakaLbl.Visible = true;
            saiphLbl.Visible = true;
            rigelLbl.Visible = true;

        }

        private void hideStarsBtn_Click(object sender, EventArgs e)
        {
            betelgeuseLbl.Visible = false;
            alrilamLbl.Visible = false;
            alritakLbl.Visible = false;
            meissaLbl.Visible = false;
            mirtakaLbl.Visible = false;
            saiphLbl.Visible = false;
            rigelLbl.Visible = false;
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
