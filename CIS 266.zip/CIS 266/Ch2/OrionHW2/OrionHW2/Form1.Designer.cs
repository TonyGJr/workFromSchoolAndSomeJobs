﻿namespace OrionHW2
{
    partial class orionConstellation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(orionConstellation));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.showStarsBtn = new System.Windows.Forms.Button();
            this.hideStarsBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.betelgeuseLbl = new System.Windows.Forms.Label();
            this.alritakLbl = new System.Windows.Forms.Label();
            this.saiphLbl = new System.Windows.Forms.Label();
            this.alrilamLbl = new System.Windows.Forms.Label();
            this.mirtakaLbl = new System.Windows.Forms.Label();
            this.meissaLbl = new System.Windows.Forms.Label();
            this.rigelLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(414, 325);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // showStarsBtn
            // 
            this.showStarsBtn.Location = new System.Drawing.Point(23, 339);
            this.showStarsBtn.Name = "showStarsBtn";
            this.showStarsBtn.Size = new System.Drawing.Size(75, 35);
            this.showStarsBtn.TabIndex = 1;
            this.showStarsBtn.Text = "Show Star Names";
            this.showStarsBtn.UseVisualStyleBackColor = true;
            this.showStarsBtn.Click += new System.EventHandler(this.showStarsBtn_Click);
            // 
            // hideStarsBtn
            // 
            this.hideStarsBtn.Location = new System.Drawing.Point(160, 339);
            this.hideStarsBtn.Name = "hideStarsBtn";
            this.hideStarsBtn.Size = new System.Drawing.Size(75, 35);
            this.hideStarsBtn.TabIndex = 2;
            this.hideStarsBtn.Text = "Hide Star Names";
            this.hideStarsBtn.UseVisualStyleBackColor = true;
            this.hideStarsBtn.Click += new System.EventHandler(this.hideStarsBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(294, 338);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(75, 36);
            this.exitBtn.TabIndex = 3;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // betelgeuseLbl
            // 
            this.betelgeuseLbl.AutoSize = true;
            this.betelgeuseLbl.Location = new System.Drawing.Point(60, 42);
            this.betelgeuseLbl.Name = "betelgeuseLbl";
            this.betelgeuseLbl.Size = new System.Drawing.Size(60, 13);
            this.betelgeuseLbl.TabIndex = 4;
            this.betelgeuseLbl.Text = "Betelgeuse";
            this.betelgeuseLbl.Visible = false;
            // 
            // alritakLbl
            // 
            this.alritakLbl.AutoSize = true;
            this.alritakLbl.Location = new System.Drawing.Point(126, 176);
            this.alritakLbl.Name = "alritakLbl";
            this.alritakLbl.Size = new System.Drawing.Size(36, 13);
            this.alritakLbl.TabIndex = 5;
            this.alritakLbl.Text = "Alritak";
            this.alritakLbl.Visible = false;
            // 
            // saiphLbl
            // 
            this.saiphLbl.AutoSize = true;
            this.saiphLbl.Location = new System.Drawing.Point(62, 272);
            this.saiphLbl.Name = "saiphLbl";
            this.saiphLbl.Size = new System.Drawing.Size(34, 13);
            this.saiphLbl.TabIndex = 6;
            this.saiphLbl.Text = "Saiph";
            this.saiphLbl.Visible = false;
            // 
            // alrilamLbl
            // 
            this.alrilamLbl.AutoSize = true;
            this.alrilamLbl.Location = new System.Drawing.Point(181, 161);
            this.alrilamLbl.Name = "alrilamLbl";
            this.alrilamLbl.Size = new System.Drawing.Size(37, 13);
            this.alrilamLbl.TabIndex = 7;
            this.alrilamLbl.Text = "Alrilam";
            this.alrilamLbl.Visible = false;
            // 
            // mirtakaLbl
            // 
            this.mirtakaLbl.AutoSize = true;
            this.mirtakaLbl.Location = new System.Drawing.Point(242, 142);
            this.mirtakaLbl.Name = "mirtakaLbl";
            this.mirtakaLbl.Size = new System.Drawing.Size(42, 13);
            this.mirtakaLbl.TabIndex = 8;
            this.mirtakaLbl.Text = "Mirtaka";
            this.mirtakaLbl.Visible = false;
            // 
            // meissaLbl
            // 
            this.meissaLbl.AutoSize = true;
            this.meissaLbl.Location = new System.Drawing.Point(294, 58);
            this.meissaLbl.Name = "meissaLbl";
            this.meissaLbl.Size = new System.Drawing.Size(40, 13);
            this.meissaLbl.TabIndex = 9;
            this.meissaLbl.Text = "Meissa";
            this.meissaLbl.Visible = false;
            // 
            // rigelLbl
            // 
            this.rigelLbl.AutoSize = true;
            this.rigelLbl.Location = new System.Drawing.Point(294, 242);
            this.rigelLbl.Name = "rigelLbl";
            this.rigelLbl.Size = new System.Drawing.Size(31, 13);
            this.rigelLbl.TabIndex = 10;
            this.rigelLbl.Text = "Rigel";
            this.rigelLbl.Visible = false;
            // 
            // orionConstellation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(418, 382);
            this.Controls.Add(this.rigelLbl);
            this.Controls.Add(this.meissaLbl);
            this.Controls.Add(this.mirtakaLbl);
            this.Controls.Add(this.alrilamLbl);
            this.Controls.Add(this.saiphLbl);
            this.Controls.Add(this.alritakLbl);
            this.Controls.Add(this.betelgeuseLbl);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.hideStarsBtn);
            this.Controls.Add(this.showStarsBtn);
            this.Controls.Add(this.pictureBox1);
            this.Name = "orionConstellation";
            this.Text = "Orion Constellation";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button showStarsBtn;
        private System.Windows.Forms.Button hideStarsBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label betelgeuseLbl;
        private System.Windows.Forms.Label alritakLbl;
        private System.Windows.Forms.Label saiphLbl;
        private System.Windows.Forms.Label alrilamLbl;
        private System.Windows.Forms.Label mirtakaLbl;
        private System.Windows.Forms.Label meissaLbl;
        private System.Windows.Forms.Label rigelLbl;
    }
}

