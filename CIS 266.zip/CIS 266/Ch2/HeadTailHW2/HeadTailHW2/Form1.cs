﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Tony Gunn Jr.
//08/31/2017
//Heads and Tails Program
namespace HeadTailHW2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void headsButton_Click(object sender, EventArgs e)
        {
            //Shows head when clicked and keeps tail hidden
            headsPicBox.Visible = true;
            tailsPicBox.Visible = false;
        }

        private void tailsButton_Click(object sender, EventArgs e)
        {
            //Shows tail when clicked and keeps head hidden
            tailsPicBox.Visible = true;
            headsPicBox.Visible = false;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
