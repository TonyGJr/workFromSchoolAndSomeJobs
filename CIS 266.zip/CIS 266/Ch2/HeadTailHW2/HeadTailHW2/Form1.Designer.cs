﻿namespace HeadTailHW2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.headsButton = new System.Windows.Forms.Button();
            this.tailsButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.headsPicBox = new System.Windows.Forms.PictureBox();
            this.tailsPicBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.headsPicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tailsPicBox)).BeginInit();
            this.SuspendLayout();
            // 
            // headsButton
            // 
            this.headsButton.Location = new System.Drawing.Point(53, 273);
            this.headsButton.Name = "headsButton";
            this.headsButton.Size = new System.Drawing.Size(85, 47);
            this.headsButton.TabIndex = 0;
            this.headsButton.Text = "Show Heads";
            this.headsButton.UseVisualStyleBackColor = true;
            this.headsButton.Click += new System.EventHandler(this.headsButton_Click);
            // 
            // tailsButton
            // 
            this.tailsButton.Location = new System.Drawing.Point(214, 273);
            this.tailsButton.Name = "tailsButton";
            this.tailsButton.Size = new System.Drawing.Size(83, 47);
            this.tailsButton.TabIndex = 1;
            this.tailsButton.Text = "Show Tails";
            this.tailsButton.UseVisualStyleBackColor = true;
            this.tailsButton.Click += new System.EventHandler(this.tailsButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(363, 273);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(83, 47);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // headsPicBox
            // 
            this.headsPicBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.headsPicBox.Image = ((System.Drawing.Image)(resources.GetObject("headsPicBox.Image")));
            this.headsPicBox.Location = new System.Drawing.Point(72, 83);
            this.headsPicBox.Name = "headsPicBox";
            this.headsPicBox.Size = new System.Drawing.Size(141, 118);
            this.headsPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.headsPicBox.TabIndex = 3;
            this.headsPicBox.TabStop = false;
            this.headsPicBox.Visible = false;
            // 
            // tailsPicBox
            // 
            this.tailsPicBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tailsPicBox.Image = ((System.Drawing.Image)(resources.GetObject("tailsPicBox.Image")));
            this.tailsPicBox.Location = new System.Drawing.Point(330, 83);
            this.tailsPicBox.Name = "tailsPicBox";
            this.tailsPicBox.Size = new System.Drawing.Size(139, 118);
            this.tailsPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tailsPicBox.TabIndex = 4;
            this.tailsPicBox.TabStop = false;
            this.tailsPicBox.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(506, 357);
            this.Controls.Add(this.tailsPicBox);
            this.Controls.Add(this.headsPicBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.tailsButton);
            this.Controls.Add(this.headsButton);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.headsPicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tailsPicBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button headsButton;
        private System.Windows.Forms.Button tailsButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox headsPicBox;
        private System.Windows.Forms.PictureBox tailsPicBox;
    }
}

