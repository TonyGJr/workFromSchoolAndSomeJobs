﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeList
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //create a List (array) to hold all the employees processed
        List<Employee> employeeList = new List<Employee>();

        private void calcButton_Click(object sender, EventArgs e)
        {
            string tempName = "";
            double tempHours = 0;
            double tempRate = 0;
            double tempWithHoldings = 0;

            //instantiate an employee object
            //Employee theEmployee = new Employee();

            //check the validation of the entries

            if (double.TryParse(hoursTextBox.Text, out tempHours))
            {
                if(double.TryParse(rateTextBox.Text, out tempRate))
                {
                    if (double.TryParse(witholdingsTextBox.Text, out tempWithHoldings))
                    {

                        // everything passed validation
                        // assign the data to the properties of the object

                        Employee theEmployee = new Employee(nameTextBox.Text, tempHours, tempRate, tempWithHoldings);

                        //tempName = nameTextBox.Text;
                        //theEmployee.Name = tempName;
                        //theEmployee.Hours = tempHours;
                        //theEmployee.Rate = tempRate;
                        //theEmployee.WithHoldings = tempWithHoldings;


                        //calc the payroll pass theEmployee to the method

                        calcPayroll(theEmployee);

                        // add the object to the list passing theEmployee
                        AddEmployeeToList(theEmployee);

                        //clear the textboxes
                        ClearText();

                        // reset the focus to the name

                    nameTextBox.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Withholding must be a number.");
                        witholdingsTextBox.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Rate must be a number.");
                    rateTextBox.Focus();
                }
            }
            else
            {
                MessageBox.Show("Hours must be a number.");
                hoursTextBox.Focus();
            }
        }

        private void calcPayroll(Employee anEmployee)
        {
            // display output
            double grossPay = 0;

            grossPay = anEmployee.CalcGrossPay();


            // instiate a new form object and display the data in that form

            DisplayForm dsForm = new DisplayForm(anEmployee);

            //this will actually force us to leave this form and show the Display Form
            dsForm.ShowDialog();



            //outputListBox.Items.Add("Name: " + anEmployee.Name);
            //outputListBox.Items.Add("Rate: " + anEmployee.Rate);
            //outputListBox.Items.Add("Hours: " + anEmployee.Hours);
            //outputListBox.Items.Add("Withholdings: " + anEmployee.WithHoldings);
            //outputListBox.Items.Add("Gross Pay: " + grossPay.ToString("n2"));
            //outputListBox.Items.Add(""); // create a blank line




        }

        private void AddEmployeeToList(Employee theEmployee)
        {
            // add the employee tp the list

            employeeList.Add(theEmployee);

            MessageBox.Show(theEmployee.Name + " was added to the list.");

        }

        private void ClearText()
        {
            // clear text boxes

            nameTextBox.Text = "";
            rateTextBox.Text = "";
            hoursTextBox.Text = "";
            witholdingsTextBox.Text = "";
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            string output = "";

            output = "\tEmployees Processed\n\n";

            for(int x = 0; x < employeeList.Count; x++)
            {
                output = output + employeeList[x].Name + "    "
                    + employeeList[x].CalcGrossPay().ToString("n2") + "\n";
            }

            outputLabel.Text = output.ToString();
        }
    }
}
