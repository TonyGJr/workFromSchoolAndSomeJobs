﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeList
{
    // Employee Class

   public class Employee   //  this is where we made the Employee class public
    {
        // Field Variables

        private string _name;
        private double _hours;
        private double _rate;
        private double _withHoldings;


        // Constructors 
                
            // null constructor
            public Employee()
            {
            _name = "";
            _hours = 0;
            _rate = 0;
            _withHoldings = 0;
            }
        
        //overloaded constructor
        public Employee(string theName, double theHours, double theRate, double theWithHoldings)
        {
            Name = theName;
            Rate = theRate;
            Hours = theHours;
            WithHoldings = theWithHoldings;
        }

        // create the properties for each field

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public double Rate
        {
            get { return _rate; }
            set { _rate = value; }

        }

        public double Hours
        {
            get { return _hours; }
            set { _hours = value; }
        }

        public double WithHoldings
        {
            get { return _withHoldings; }
            set { _withHoldings = value; }
        }

        public double CalcGrossPay()
        {
            double otPay = 0;
            double grossPay = 0;
            double regPay = 0;

            if (_hours > 40)
            {
                otPay = (_hours - 40) * (_rate * 1.5);
                regPay = (40 * _rate);
                grossPay = otPay + regPay;
            }

            else
            {
                grossPay = (_hours * _rate);
            }

            return grossPay;
        }
    }
}
