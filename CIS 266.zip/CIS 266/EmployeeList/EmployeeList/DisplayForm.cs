﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeList
{
    public partial class DisplayForm : Form
    {

        //Field
        Employee _emp;

        // Constructor method
        public DisplayForm()
        {
            InitializeComponent();
        }

        public DisplayForm(Employee theEmployee)  //We had to set the Employee class to public to get the error away ....this is needed to be seen by each other
        {
            InitializeComponent();
            _emp = theEmployee;



        }


        private void showBtn_Click(object sender, EventArgs e)
        {
            //display the employee data
            outputLbl.Text = _emp.Name + " " + _emp.Rate.ToString("n2");

        }
    }
}
