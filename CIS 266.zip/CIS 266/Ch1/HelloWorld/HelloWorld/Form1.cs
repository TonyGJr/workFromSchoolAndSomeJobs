﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Tony Gunn
//Aug. 24, 2017
//Hello World Program

namespace HelloWorld
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            //Write the code to display hello world

            outputLabel.Text = "Hello World \n" +
                                "By Tony Gunn Jr.";
        }
    }
}
