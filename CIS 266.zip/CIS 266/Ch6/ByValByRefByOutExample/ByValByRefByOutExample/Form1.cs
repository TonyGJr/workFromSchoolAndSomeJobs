﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* 
 Gunn, Tony
 10/20/2017
 This program will pass data by value, out, and reference
 */

namespace ByValByRefByOutExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void byValBtn_Click(object sender, EventArgs e)
        {
            // Pass by Val Example

            double value = 0;

            if (double.TryParse(numByValBeforeTB.Text, out value))
            {
                // passed validatiob, so pass by val to method

                ByVal(value);

                // display the value
                outputByValLbl.Text = value.ToString();
            }
        }
        private void ByVal(double theValue)
        {
            // change theValue number
            theValue = 10;
        }
        private void byRefBtn_Click(object sender, EventArgs e)
        {
            // Pass by Val Example

            double value = 0;

            if (double.TryParse(numByRefBeforeTB.Text, out value))
            {
                // passed validatiob, so pass by val to method

                ByRef(ref value);

                // display the value
                outputByRefLbl.Text = value.ToString();
            }
        }
        private void ByRef(ref double theValue)
        {
            // change theValue number
            theValue = 10;
        }

        private void byOutBtn_Click(object sender, EventArgs e)
        {
            // Pass by Val Example
            double value = 0;

            if (double.TryParse(numByOutBeforeTB.Text, out value))
            {
                // passed validatiob, so pass by val to method
                ByOut(out value);

                // display the value
                outputByOutLbl.Text = value.ToString();
            }
        }

        private void ByOut(out double theValue)
        {
            // change theValue number
            theValue = 10;
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            numByValBeforeTB.Text = "";
            numByRefBeforeTB.Text = "";
            numByOutBeforeTB.Text = "";
            outputByOutLbl.Text = "";
            outputByRefLbl.Text = "";
            outputByValLbl.Text = "";
            numByValBeforeTB.Focus();
        }
        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}