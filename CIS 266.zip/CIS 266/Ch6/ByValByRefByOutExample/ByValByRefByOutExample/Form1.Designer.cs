﻿namespace ByValByRefByOutExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numByValBeforeTB = new System.Windows.Forms.TextBox();
            this.byValBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.outputByValLbl = new System.Windows.Forms.Label();
            this.outputByRefLbl = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.byRefBtn = new System.Windows.Forms.Button();
            this.numByRefBeforeTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.outputByOutLbl = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.byOutBtn = new System.Windows.Forms.Button();
            this.numByOutBeforeTB = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.clearBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(76, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "By Val";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label2.Location = new System.Drawing.Point(88, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number Before Passing:";
            // 
            // numByValBeforeTB
            // 
            this.numByValBeforeTB.Location = new System.Drawing.Point(226, 62);
            this.numByValBeforeTB.Name = "numByValBeforeTB";
            this.numByValBeforeTB.Size = new System.Drawing.Size(100, 20);
            this.numByValBeforeTB.TabIndex = 2;
            // 
            // byValBtn
            // 
            this.byValBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.byValBtn.Location = new System.Drawing.Point(365, 50);
            this.byValBtn.Name = "byValBtn";
            this.byValBtn.Size = new System.Drawing.Size(81, 42);
            this.byValBtn.TabIndex = 3;
            this.byValBtn.Text = "Pass By Val";
            this.byValBtn.UseVisualStyleBackColor = true;
            this.byValBtn.Click += new System.EventHandler(this.byValBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(464, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Number After Pass By Val:";
            // 
            // outputByValLbl
            // 
            this.outputByValLbl.BackColor = System.Drawing.Color.PaleGreen;
            this.outputByValLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputByValLbl.Location = new System.Drawing.Point(614, 59);
            this.outputByValLbl.Name = "outputByValLbl";
            this.outputByValLbl.Size = new System.Drawing.Size(154, 23);
            this.outputByValLbl.TabIndex = 5;
            // 
            // outputByRefLbl
            // 
            this.outputByRefLbl.BackColor = System.Drawing.Color.PaleGreen;
            this.outputByRefLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputByRefLbl.Location = new System.Drawing.Point(614, 159);
            this.outputByRefLbl.Name = "outputByRefLbl";
            this.outputByRefLbl.Size = new System.Drawing.Size(154, 23);
            this.outputByRefLbl.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(464, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Number After Pass By Ref:";
            // 
            // byRefBtn
            // 
            this.byRefBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.byRefBtn.Location = new System.Drawing.Point(365, 150);
            this.byRefBtn.Name = "byRefBtn";
            this.byRefBtn.Size = new System.Drawing.Size(81, 42);
            this.byRefBtn.TabIndex = 9;
            this.byRefBtn.Text = "Pass By Ref";
            this.byRefBtn.UseVisualStyleBackColor = true;
            this.byRefBtn.Click += new System.EventHandler(this.byRefBtn_Click);
            // 
            // numByRefBeforeTB
            // 
            this.numByRefBeforeTB.Location = new System.Drawing.Point(226, 162);
            this.numByRefBeforeTB.Name = "numByRefBeforeTB";
            this.numByRefBeforeTB.Size = new System.Drawing.Size(100, 20);
            this.numByRefBeforeTB.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label6.Location = new System.Drawing.Point(88, 165);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Number Before Passing:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(76, 138);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "By Ref";
            // 
            // outputByOutLbl
            // 
            this.outputByOutLbl.BackColor = System.Drawing.Color.PaleGreen;
            this.outputByOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputByOutLbl.Location = new System.Drawing.Point(614, 260);
            this.outputByOutLbl.Name = "outputByOutLbl";
            this.outputByOutLbl.Size = new System.Drawing.Size(154, 23);
            this.outputByOutLbl.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(464, 266);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(133, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Number After Pass By Out:";
            // 
            // byOutBtn
            // 
            this.byOutBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.byOutBtn.Location = new System.Drawing.Point(365, 251);
            this.byOutBtn.Name = "byOutBtn";
            this.byOutBtn.Size = new System.Drawing.Size(81, 42);
            this.byOutBtn.TabIndex = 15;
            this.byOutBtn.Text = "Pass By Out";
            this.byOutBtn.UseVisualStyleBackColor = true;
            this.byOutBtn.Click += new System.EventHandler(this.byOutBtn_Click);
            // 
            // numByOutBeforeTB
            // 
            this.numByOutBeforeTB.Location = new System.Drawing.Point(226, 263);
            this.numByOutBeforeTB.Name = "numByOutBeforeTB";
            this.numByOutBeforeTB.Size = new System.Drawing.Size(100, 20);
            this.numByOutBeforeTB.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label10.Location = new System.Drawing.Point(88, 266);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Number Before Passing:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(76, 239);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 20);
            this.label11.TabIndex = 12;
            this.label11.Text = "By Out";
            // 
            // clearBtn
            // 
            this.clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.Location = new System.Drawing.Point(237, 325);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(99, 42);
            this.clearBtn.TabIndex = 18;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBtn.Location = new System.Drawing.Point(525, 325);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(99, 42);
            this.exitBtn.TabIndex = 19;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(913, 379);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.outputByOutLbl);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.byOutBtn);
            this.Controls.Add(this.numByOutBeforeTB);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.outputByRefLbl);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.byRefBtn);
            this.Controls.Add(this.numByRefBeforeTB);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.outputByValLbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.byValBtn);
            this.Controls.Add(this.numByValBeforeTB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "By Val By Ref By Out Example";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox numByValBeforeTB;
        private System.Windows.Forms.Button byValBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label outputByValLbl;
        private System.Windows.Forms.Label outputByRefLbl;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button byRefBtn;
        private System.Windows.Forms.TextBox numByRefBeforeTB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label outputByOutLbl;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button byOutBtn;
        private System.Windows.Forms.TextBox numByOutBeforeTB;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button exitBtn;
    }
}

