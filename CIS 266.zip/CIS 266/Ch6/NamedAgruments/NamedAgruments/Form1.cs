﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NamedAgruments
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calBtn_Click(object sender, EventArgs e)
        {
            // Cal the pay

            double rate = 0;
            double hours = 0;
            double grossPay = 0;
            string name = "";

            if (double.TryParse(rateTB.Text, out rate))
            {
                if (double.TryParse(hoursTB.Text, out hours))
                {
                    // everything passed validation, do calc the pay

                    if (hours > 40)
                    {
                        // invoke the OTPay Method
                        grossPay = OTPay(rate, hours);
                    }
                    // invoke a named Argument to display the output
                    DisplayPay(theGrossPay: grossPay, theHours: hours, theName: nameTB.Text, theRate: rate);
                }
                else
                {
                    // the hours failed validation
                    MessageBox.Show("The hours must be a number.");
                    hoursTB.Focus();
                }
            }

            else
            {
                // the rate failed validation
                MessageBox.Show("The rate must be a number.");
                rateTB.Focus();
            }
        }
        private double OTPay(double theRate, double theHours)
        {
            //calc ot pay

            double OTPayAmt = 0;
            double regPayAmt = 0;
            double grossPayAmt = 0;

            OTPayAmt = (theRate * 1.5) * (theHours - 40);
            regPayAmt = theRate * 40;
            grossPayAmt = OTPayAmt + regPayAmt;

            // return the gross pay
            return grossPayAmt;

        }
        private void DisplayPay(string theName, double theRate, double theHours, double theGrossPay)
        {
            outputLbl.Text = "Name: " + theName + "\n"
            + "Rate: " + theRate.ToString("c2") + "\n"
            + "Hours: " + theHours.ToString("n2") + "\n"
            + "Gross Pay: " + theGrossPay.ToString("c");
        }
    }
}
