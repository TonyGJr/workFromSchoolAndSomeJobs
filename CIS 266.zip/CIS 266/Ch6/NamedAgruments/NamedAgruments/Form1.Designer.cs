﻿namespace NamedAgruments
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rateTB = new System.Windows.Forms.TextBox();
            this.hoursTB = new System.Windows.Forms.TextBox();
            this.outputLbl = new System.Windows.Forms.Label();
            this.calBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameTB
            // 
            this.nameTB.Location = new System.Drawing.Point(117, 70);
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(100, 20);
            this.nameTB.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Rate:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Hours:";
            // 
            // rateTB
            // 
            this.rateTB.Location = new System.Drawing.Point(117, 104);
            this.rateTB.Name = "rateTB";
            this.rateTB.Size = new System.Drawing.Size(100, 20);
            this.rateTB.TabIndex = 4;
            // 
            // hoursTB
            // 
            this.hoursTB.Location = new System.Drawing.Point(117, 134);
            this.hoursTB.Name = "hoursTB";
            this.hoursTB.Size = new System.Drawing.Size(100, 20);
            this.hoursTB.TabIndex = 5;
            // 
            // outputLbl
            // 
            this.outputLbl.BackColor = System.Drawing.Color.MistyRose;
            this.outputLbl.Location = new System.Drawing.Point(73, 182);
            this.outputLbl.Name = "outputLbl";
            this.outputLbl.Size = new System.Drawing.Size(292, 144);
            this.outputLbl.TabIndex = 6;
            // 
            // calBtn
            // 
            this.calBtn.Location = new System.Drawing.Point(133, 357);
            this.calBtn.Name = "calBtn";
            this.calBtn.Size = new System.Drawing.Size(138, 52);
            this.calBtn.TabIndex = 7;
            this.calBtn.Text = "Calculate";
            this.calBtn.UseVisualStyleBackColor = true;
            this.calBtn.Click += new System.EventHandler(this.calBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 466);
            this.Controls.Add(this.calBtn);
            this.Controls.Add(this.outputLbl);
            this.Controls.Add(this.hoursTB);
            this.Controls.Add(this.rateTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nameTB);
            this.Name = "Form1";
            this.Text = "Named Argumetnts Example";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox rateTB;
        private System.Windows.Forms.TextBox hoursTB;
        private System.Windows.Forms.Label outputLbl;
        private System.Windows.Forms.Button calBtn;
    }
}

