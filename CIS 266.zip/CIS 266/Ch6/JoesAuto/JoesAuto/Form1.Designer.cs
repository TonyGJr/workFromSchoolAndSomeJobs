﻿namespace JoesAuto
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lubeCB = new System.Windows.Forms.CheckBox();
            this.oilChangeCB = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.transFlushCB = new System.Windows.Forms.CheckBox();
            this.radiatorFlushCB = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tireCB = new System.Windows.Forms.CheckBox();
            this.mufflerCB = new System.Windows.Forms.CheckBox();
            this.inspectionCB = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.laborTb = new System.Windows.Forms.TextBox();
            this.partsTb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.totalFeesOutputLbl = new System.Windows.Forms.Label();
            this.taxOnPartsOutputLbl = new System.Windows.Forms.Label();
            this.partsOutputLbl = new System.Windows.Forms.Label();
            this.serviceLaborOutputLbl = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.calBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.groupBox1.Controls.Add(this.lubeCB);
            this.groupBox1.Controls.Add(this.oilChangeCB);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(25, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(209, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Oil and Lube";
            // 
            // lubeCB
            // 
            this.lubeCB.AutoSize = true;
            this.lubeCB.Location = new System.Drawing.Point(17, 55);
            this.lubeCB.Name = "lubeCB";
            this.lubeCB.Size = new System.Drawing.Size(149, 20);
            this.lubeCB.TabIndex = 1;
            this.lubeCB.Text = "Lube Job ($18.00)";
            this.lubeCB.UseVisualStyleBackColor = true;
            // 
            // oilChangeCB
            // 
            this.oilChangeCB.AutoSize = true;
            this.oilChangeCB.Location = new System.Drawing.Point(17, 20);
            this.oilChangeCB.Name = "oilChangeCB";
            this.oilChangeCB.Size = new System.Drawing.Size(161, 20);
            this.oilChangeCB.TabIndex = 0;
            this.oilChangeCB.Text = "Oil Change ($26.00)";
            this.oilChangeCB.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.transFlushCB);
            this.groupBox2.Controls.Add(this.radiatorFlushCB);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(287, 41);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(218, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Flushes";
            // 
            // transFlushCB
            // 
            this.transFlushCB.AutoSize = true;
            this.transFlushCB.Location = new System.Drawing.Point(4, 55);
            this.transFlushCB.Name = "transFlushCB";
            this.transFlushCB.Size = new System.Drawing.Size(219, 20);
            this.transFlushCB.TabIndex = 3;
            this.transFlushCB.Text = "Transmission Flush ($80.00)";
            this.transFlushCB.UseVisualStyleBackColor = true;
            // 
            // radiatorFlushCB
            // 
            this.radiatorFlushCB.AutoSize = true;
            this.radiatorFlushCB.Location = new System.Drawing.Point(4, 20);
            this.radiatorFlushCB.Name = "radiatorFlushCB";
            this.radiatorFlushCB.Size = new System.Drawing.Size(186, 20);
            this.radiatorFlushCB.TabIndex = 2;
            this.radiatorFlushCB.Text = "Radiator Flush ($30.00)";
            this.radiatorFlushCB.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.groupBox3.Controls.Add(this.tireCB);
            this.groupBox3.Controls.Add(this.mufflerCB);
            this.groupBox3.Controls.Add(this.inspectionCB);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(25, 185);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(209, 100);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Mics.";
            // 
            // tireCB
            // 
            this.tireCB.AutoSize = true;
            this.tireCB.Location = new System.Drawing.Point(6, 72);
            this.tireCB.Name = "tireCB";
            this.tireCB.Size = new System.Drawing.Size(175, 20);
            this.tireCB.TabIndex = 6;
            this.tireCB.Text = "Tire Rotation ($20.00)";
            this.tireCB.UseVisualStyleBackColor = true;
            // 
            // mufflerCB
            // 
            this.mufflerCB.AutoSize = true;
            this.mufflerCB.Location = new System.Drawing.Point(6, 47);
            this.mufflerCB.Name = "mufflerCB";
            this.mufflerCB.Size = new System.Drawing.Size(202, 20);
            this.mufflerCB.TabIndex = 5;
            this.mufflerCB.Text = "Replace Muffler ($100.00)";
            this.mufflerCB.UseVisualStyleBackColor = true;
            // 
            // inspectionCB
            // 
            this.inspectionCB.AutoSize = true;
            this.inspectionCB.Location = new System.Drawing.Point(6, 22);
            this.inspectionCB.Name = "inspectionCB";
            this.inspectionCB.Size = new System.Drawing.Size(156, 20);
            this.inspectionCB.TabIndex = 4;
            this.inspectionCB.Text = "Inspection ($15.00)";
            this.inspectionCB.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.laborTb);
            this.groupBox4.Controls.Add(this.partsTb);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(287, 185);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(218, 100);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Parts and Labor";
            // 
            // laborTb
            // 
            this.laborTb.Location = new System.Drawing.Point(78, 53);
            this.laborTb.Name = "laborTb";
            this.laborTb.Size = new System.Drawing.Size(100, 22);
            this.laborTb.TabIndex = 3;
            // 
            // partsTb
            // 
            this.partsTb.Location = new System.Drawing.Point(79, 28);
            this.partsTb.Name = "partsTb";
            this.partsTb.Size = new System.Drawing.Size(100, 22);
            this.partsTb.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Labor";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Parts";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox5.Controls.Add(this.totalFeesOutputLbl);
            this.groupBox5.Controls.Add(this.taxOnPartsOutputLbl);
            this.groupBox5.Controls.Add(this.partsOutputLbl);
            this.groupBox5.Controls.Add(this.serviceLaborOutputLbl);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(59, 331);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(436, 137);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Summary";
            // 
            // totalFeesOutputLbl
            // 
            this.totalFeesOutputLbl.BackColor = System.Drawing.Color.White;
            this.totalFeesOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalFeesOutputLbl.Location = new System.Drawing.Point(177, 102);
            this.totalFeesOutputLbl.Name = "totalFeesOutputLbl";
            this.totalFeesOutputLbl.Size = new System.Drawing.Size(151, 23);
            this.totalFeesOutputLbl.TabIndex = 7;
            // 
            // taxOnPartsOutputLbl
            // 
            this.taxOnPartsOutputLbl.BackColor = System.Drawing.Color.White;
            this.taxOnPartsOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.taxOnPartsOutputLbl.Location = new System.Drawing.Point(177, 77);
            this.taxOnPartsOutputLbl.Name = "taxOnPartsOutputLbl";
            this.taxOnPartsOutputLbl.Size = new System.Drawing.Size(151, 23);
            this.taxOnPartsOutputLbl.TabIndex = 6;
            // 
            // partsOutputLbl
            // 
            this.partsOutputLbl.BackColor = System.Drawing.Color.White;
            this.partsOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.partsOutputLbl.Location = new System.Drawing.Point(177, 52);
            this.partsOutputLbl.Name = "partsOutputLbl";
            this.partsOutputLbl.Size = new System.Drawing.Size(151, 23);
            this.partsOutputLbl.TabIndex = 5;
            // 
            // serviceLaborOutputLbl
            // 
            this.serviceLaborOutputLbl.BackColor = System.Drawing.Color.White;
            this.serviceLaborOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.serviceLaborOutputLbl.Location = new System.Drawing.Point(177, 26);
            this.serviceLaborOutputLbl.Name = "serviceLaborOutputLbl";
            this.serviceLaborOutputLbl.Size = new System.Drawing.Size(151, 23);
            this.serviceLaborOutputLbl.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(35, 103);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 16);
            this.label6.TabIndex = 3;
            this.label6.Text = "Total Fees:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Tax (on parts):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Parts:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Service and Labor:";
            // 
            // calBtn
            // 
            this.calBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calBtn.Location = new System.Drawing.Point(42, 499);
            this.calBtn.Name = "calBtn";
            this.calBtn.Size = new System.Drawing.Size(100, 35);
            this.calBtn.TabIndex = 4;
            this.calBtn.Text = "Calculate";
            this.calBtn.UseVisualStyleBackColor = true;
            this.calBtn.Click += new System.EventHandler(this.calBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.Location = new System.Drawing.Point(198, 499);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(100, 35);
            this.clearBtn.TabIndex = 5;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBtn.Location = new System.Drawing.Point(387, 499);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(100, 35);
            this.exitBtn.TabIndex = 6;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(155, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(253, 33);
            this.label7.TabIndex = 7;
            this.label7.Text = "Joe\'s Automotive";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(580, 546);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.calBtn);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Joe\'s Automotive";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox lubeCB;
        private System.Windows.Forms.CheckBox oilChangeCB;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox transFlushCB;
        private System.Windows.Forms.CheckBox radiatorFlushCB;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox tireCB;
        private System.Windows.Forms.CheckBox mufflerCB;
        private System.Windows.Forms.CheckBox inspectionCB;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox laborTb;
        private System.Windows.Forms.TextBox partsTb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label totalFeesOutputLbl;
        private System.Windows.Forms.Label taxOnPartsOutputLbl;
        private System.Windows.Forms.Label partsOutputLbl;
        private System.Windows.Forms.Label serviceLaborOutputLbl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button calBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label label7;
    }
}

