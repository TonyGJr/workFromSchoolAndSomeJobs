﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* Gunn, Tony
 10/25/2017
 This program will calc the fees for Joe's Automotive
 */
namespace JoesAuto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calBtn_Click(object sender, EventArgs e)
        {
            double TAXES = .06;

            double parts = 0;
            double labor = 0;
            double otherCharges = 0;
            double oilLubeCharges = 0;
            double flushCharges = 0;
            double miscCharges = 0;
            double taxCharges = 0;
            double totalCharges = 0;

            

            if (IsValid(theParts: ref parts, theLabor: ref labor))
            {
                otherCharges = OtherCharges(theParts: ref parts, theLabor: ref labor);
                oilLubeCharges = OilLubeCharges();
                flushCharges = FlushCharges();
                miscCharges = Misc();
                taxCharges = TaxCharges(theParts: ref parts, theTAX: ref TAXES);
                totalCharges = TotalCharges(theOilLubeCh: ref oilLubeCharges, theFlushesCh: ref flushCharges, 
                    theMiscCh: ref miscCharges, theTaxCh: ref taxCharges, theOtherCh: ref otherCharges);

            }

            DisplayMethod(theOilLubeCh: ref oilLubeCharges, theFlushesCh: ref flushCharges,
                    theMiscCh: ref miscCharges, theTaxCh: ref taxCharges, theOtherCh: ref otherCharges, thetotalCharges: ref totalCharges, theLabor: ref labor, theParts: ref parts);
        }

        private bool IsValid(ref double theLabor, ref double theParts)
        {
            bool InputValid = false;
            if (double.TryParse(partsTb.Text, out theParts))
            {
                if (double.TryParse(laborTb.Text, out theLabor))
                {
                    InputValid = true;
                }
                else
                {
                    MessageBox.Show("Please Enter A Number In the Parts Field");
                    partsTb.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please Enter A Number In the Labor Field");
                laborTb.Focus();
            }

            return InputValid;
        }

        private double OtherCharges(ref double theParts, ref double theLabor)
        {
            double servicelaborTotal = 0;

            servicelaborTotal = theParts + theLabor;

            return servicelaborTotal;
        }

        private double TaxCharges(ref double theParts, ref double theTAX)
        {
            
            double salesTax = 0;

            salesTax = theParts * theTAX;

            return salesTax;
        }

        private double OilLubeCharges()
        {
            double oilCharge = 0;
            double lubeJobCharge = 0;
            double oilLubeCharge = 0;

            if (oilChangeCB.Checked)
            {
                oilCharge = 26.00;

            }
            else
            {
                oilCharge = 0;
            }
            if (lubeCB.Checked)
            {
                lubeJobCharge = 18.00;
            }
            else
            {
                lubeJobCharge = 0;
            }

            oilLubeCharge = oilCharge + lubeJobCharge;

            return oilLubeCharge;
        }

        private double FlushCharges()
        {

            double radFlushCharge = 0;
            double transFlushCharge = 0;
            double radAndTransCharge = 0;


            if(radiatorFlushCB.Checked)
            {
                radFlushCharge = 30.00;
            }
            else
            {
                radFlushCharge = 0;
            }
            if(transFlushCB.Checked)
            {
                transFlushCharge = 80;
            }
            else
            {
                transFlushCharge = 0;
            }

            radAndTransCharge = radFlushCharge + transFlushCharge;

            return radAndTransCharge;
        }

        private double Misc()
        {
            double inspection = 0;
            double muffler = 0;
            double tire = 0;
            double miscCharges = 0;

            if(inspectionCB.Checked)
            {
                inspection = 15.00;
            }
            else
            {
                inspection = 0;
            }
            if(mufflerCB.Checked)
            {
                muffler = 100.00;
            }
            else
            {
                muffler = 0;
            }
            if(tireCB.Checked)
            {
                tire = 20.00;
            }
            else
            {
                tire = 0;
            }
            miscCharges = inspection + muffler + tire;

            return miscCharges;
        }

        private double TotalCharges(ref double theFlushesCh, ref double theMiscCh, ref double theOilLubeCh, ref double theOtherCh, ref double theTaxCh )
        {
            double totalCharges = 0;

            totalCharges = theFlushesCh + theOilLubeCh + theOtherCh + theMiscCh + theTaxCh;

            return totalCharges;
        }

        private void DisplayMethod(ref double theFlushesCh, ref double theMiscCh, ref double theOilLubeCh, ref double theOtherCh, ref double theTaxCh, ref double thetotalCharges, ref double theLabor, ref double theParts)
        {
            double serviceLaborFinal = 0;

            serviceLaborFinal = theFlushesCh + theOilLubeCh + theMiscCh + theLabor;
            serviceLaborOutputLbl.Text = serviceLaborFinal.ToString("c");
            taxOnPartsOutputLbl.Text = theTaxCh.ToString("c");
            totalFeesOutputLbl.Text = thetotalCharges.ToString("c");
            partsOutputLbl.Text = theParts.ToString("c");
           

        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }


        private void ClearOilLube()
        {
            
            oilChangeCB.Checked = false;
            lubeCB.Checked = false;
        }

        private void ClearFlushes()
        {

            radiatorFlushCB.Checked = false;
            transFlushCB.Checked = false;
        }

        private void ClearMisc()
        {
            inspectionCB.Checked = false;
            mufflerCB.Checked = false;
            tireCB.Checked = false;
        }

        private void ClearOther()
        {
            
            partsTb.Text = "";
            laborTb.Text = "";
        }

        private void ClearFees()
        {
            
            serviceLaborOutputLbl.Text = "";
            partsOutputLbl.Text = "";
            taxOnPartsOutputLbl.Text = "";
            totalFeesOutputLbl.Text = "";
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
