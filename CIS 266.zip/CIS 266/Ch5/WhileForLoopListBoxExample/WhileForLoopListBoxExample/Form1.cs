﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WhileForLoopListBoxExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void whileBtn_Click(object sender, EventArgs e)
        {
            int begNum = 0;
            int endNum = 0;

            //get the data from the textboxes

            begNum = int.Parse(valOneTb.Text);
            endNum = int.Parse(valTwoTB.Text);

            //open the while loop

            while (begNum <= endNum)
            {
                outputLB.Items.Add("Itteration: " + begNum.ToString());
                begNum++;
            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            //delete content from textboxes and the listbox
            valOneTb.Text = "";
            valTwoTB.Text = "";
            outputLB.Items.Clear();
            valOneTb.Focus();
        }

        private void forBtn_Click(object sender, EventArgs e)
        {
            //for loop example
            int begNum = 0;
            int endNum = 0;

            begNum = int.Parse(valOneTb.Text);
            endNum = int.Parse(valTwoTB.Text);

            //start the for loop

            for(int x = begNum; x<= endNum; x++)
            {
                outputLB.Items.Add("Itteration: " + x.ToString());

            }
        }

        private void backForLoopBtn_Click(object sender, EventArgs e)
        {
            int begNum = 0;
            int endNum = 0;

            begNum = int.Parse(valOneTb.Text);
            endNum = int.Parse(valTwoTB.Text);

            //start the count backwards for loop

            for (int x = endNum; x >= begNum; x--)
            {
                outputLB.Items.Add("Itteration: " + x.ToString());
            }
        }
    }
}
