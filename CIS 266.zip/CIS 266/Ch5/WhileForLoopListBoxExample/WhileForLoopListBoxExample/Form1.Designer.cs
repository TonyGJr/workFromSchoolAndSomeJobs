﻿namespace WhileForLoopListBoxExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.valOneTb = new System.Windows.Forms.TextBox();
            this.valTwoTB = new System.Windows.Forms.TextBox();
            this.outputLB = new System.Windows.Forms.ListBox();
            this.whileBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.forBtn = new System.Windows.Forms.Button();
            this.backForLoopBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Value One:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter Value Two:";
            // 
            // valOneTb
            // 
            this.valOneTb.Location = new System.Drawing.Point(175, 42);
            this.valOneTb.Name = "valOneTb";
            this.valOneTb.Size = new System.Drawing.Size(100, 20);
            this.valOneTb.TabIndex = 2;
            // 
            // valTwoTB
            // 
            this.valTwoTB.Location = new System.Drawing.Point(175, 84);
            this.valTwoTB.Name = "valTwoTB";
            this.valTwoTB.Size = new System.Drawing.Size(100, 20);
            this.valTwoTB.TabIndex = 3;
            // 
            // outputLB
            // 
            this.outputLB.FormattingEnabled = true;
            this.outputLB.Location = new System.Drawing.Point(89, 139);
            this.outputLB.Name = "outputLB";
            this.outputLB.Size = new System.Drawing.Size(186, 95);
            this.outputLB.TabIndex = 4;
            // 
            // whileBtn
            // 
            this.whileBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.whileBtn.Location = new System.Drawing.Point(25, 272);
            this.whileBtn.Name = "whileBtn";
            this.whileBtn.Size = new System.Drawing.Size(79, 49);
            this.whileBtn.TabIndex = 5;
            this.whileBtn.Text = "While Example";
            this.whileBtn.UseVisualStyleBackColor = true;
            this.whileBtn.Click += new System.EventHandler(this.whileBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.Location = new System.Drawing.Point(282, 272);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 49);
            this.clearBtn.TabIndex = 6;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // forBtn
            // 
            this.forBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forBtn.Location = new System.Drawing.Point(110, 272);
            this.forBtn.Name = "forBtn";
            this.forBtn.Size = new System.Drawing.Size(79, 49);
            this.forBtn.TabIndex = 7;
            this.forBtn.Text = "For Loop Example";
            this.forBtn.UseVisualStyleBackColor = true;
            this.forBtn.Click += new System.EventHandler(this.forBtn_Click);
            // 
            // backForLoopBtn
            // 
            this.backForLoopBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backForLoopBtn.Location = new System.Drawing.Point(195, 272);
            this.backForLoopBtn.Name = "backForLoopBtn";
            this.backForLoopBtn.Size = new System.Drawing.Size(79, 59);
            this.backForLoopBtn.TabIndex = 8;
            this.backForLoopBtn.Text = "Back For Loop Example";
            this.backForLoopBtn.UseVisualStyleBackColor = true;
            this.backForLoopBtn.Click += new System.EventHandler(this.backForLoopBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 385);
            this.Controls.Add(this.backForLoopBtn);
            this.Controls.Add(this.forBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.whileBtn);
            this.Controls.Add(this.outputLB);
            this.Controls.Add(this.valTwoTB);
            this.Controls.Add(this.valOneTb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "While, For Loop and ListBox Example";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox valOneTb;
        private System.Windows.Forms.TextBox valTwoTB;
        private System.Windows.Forms.ListBox outputLB;
        private System.Windows.Forms.Button whileBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button forBtn;
        private System.Windows.Forms.Button backForLoopBtn;
    }
}

