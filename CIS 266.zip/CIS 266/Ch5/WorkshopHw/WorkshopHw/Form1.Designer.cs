﻿namespace WorkshopHw
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.workshopLB = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.locationLB = new System.Windows.Forms.ListBox();
            this.extraGB = new System.Windows.Forms.GroupBox();
            this.socialEventCB = new System.Windows.Forms.CheckBox();
            this.securityCB = new System.Windows.Forms.CheckBox();
            this.programmingCB = new System.Windows.Forms.CheckBox();
            this.insuranceGB = new System.Windows.Forms.GroupBox();
            this.insuranceRB = new System.Windows.Forms.RadioButton();
            this.noInsuranceRB = new System.Windows.Forms.RadioButton();
            this.addNightLB = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.outputLbl = new System.Windows.Forms.Label();
            this.calBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.extraGB.SuspendLayout();
            this.insuranceGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // workshopLB
            // 
            this.workshopLB.FormattingEnabled = true;
            this.workshopLB.Items.AddRange(new object[] {
            "Handling Stress\t3 Days\t$1,000",
            "Time Management\t3 Days\t$800",
            "Supervison Skills\t3 Days\t$1,500",
            "Negotiation\t5 Days\t$1,300",
            "How to Interview\t1 Day\t$500"});
            this.workshopLB.Location = new System.Drawing.Point(12, 38);
            this.workshopLB.Name = "workshopLB";
            this.workshopLB.Size = new System.Drawing.Size(208, 56);
            this.workshopLB.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Workshop / # of Days/Registration Fee";
            // 
            // locationLB
            // 
            this.locationLB.FormattingEnabled = true;
            this.locationLB.Items.AddRange(new object[] {
            "Austin\t$150",
            "Chicago\t$225",
            "Dallas\t$175",
            "Orlando\t$300",
            "Phoenix\t$175",
            "Raleigh\t$150"});
            this.locationLB.Location = new System.Drawing.Point(284, 38);
            this.locationLB.Name = "locationLB";
            this.locationLB.Size = new System.Drawing.Size(137, 56);
            this.locationLB.TabIndex = 2;
            // 
            // extraGB
            // 
            this.extraGB.Controls.Add(this.socialEventCB);
            this.extraGB.Controls.Add(this.securityCB);
            this.extraGB.Controls.Add(this.programmingCB);
            this.extraGB.Location = new System.Drawing.Point(12, 132);
            this.extraGB.Name = "extraGB";
            this.extraGB.Size = new System.Drawing.Size(200, 118);
            this.extraGB.TabIndex = 3;
            this.extraGB.TabStop = false;
            this.extraGB.Text = "Conference Extras";
            // 
            // socialEventCB
            // 
            this.socialEventCB.AutoSize = true;
            this.socialEventCB.Location = new System.Drawing.Point(4, 88);
            this.socialEventCB.Name = "socialEventCB";
            this.socialEventCB.Size = new System.Drawing.Size(131, 17);
            this.socialEventCB.TabIndex = 2;
            this.socialEventCB.Text = "Social Event -  $25.00";
            this.socialEventCB.UseVisualStyleBackColor = true;
            // 
            // securityCB
            // 
            this.securityCB.AutoSize = true;
            this.securityCB.Location = new System.Drawing.Point(4, 53);
            this.securityCB.Name = "securityCB";
            this.securityCB.Size = new System.Drawing.Size(156, 17);
            this.securityCB.TabIndex = 1;
            this.securityCB.Text = "Security Training -  $125.00";
            this.securityCB.UseVisualStyleBackColor = true;
            // 
            // programmingCB
            // 
            this.programmingCB.AutoSize = true;
            this.programmingCB.Location = new System.Drawing.Point(4, 19);
            this.programmingCB.Name = "programmingCB";
            this.programmingCB.Size = new System.Drawing.Size(196, 17);
            this.programmingCB.TabIndex = 0;
            this.programmingCB.Text = "C# Programming Training -  $125.00";
            this.programmingCB.UseVisualStyleBackColor = true;
            // 
            // insuranceGB
            // 
            this.insuranceGB.Controls.Add(this.insuranceRB);
            this.insuranceGB.Controls.Add(this.noInsuranceRB);
            this.insuranceGB.Location = new System.Drawing.Point(284, 132);
            this.insuranceGB.Name = "insuranceGB";
            this.insuranceGB.Size = new System.Drawing.Size(137, 83);
            this.insuranceGB.TabIndex = 4;
            this.insuranceGB.TabStop = false;
            this.insuranceGB.Text = "Cancellation Insurance";
            // 
            // insuranceRB
            // 
            this.insuranceRB.AutoSize = true;
            this.insuranceRB.Location = new System.Drawing.Point(17, 53);
            this.insuranceRB.Name = "insuranceRB";
            this.insuranceRB.Size = new System.Drawing.Size(114, 17);
            this.insuranceRB.TabIndex = 1;
            this.insuranceRB.TabStop = true;
            this.insuranceRB.Text = "Insurance - $30.00";
            this.insuranceRB.UseVisualStyleBackColor = true;
            // 
            // noInsuranceRB
            // 
            this.noInsuranceRB.AutoSize = true;
            this.noInsuranceRB.Checked = true;
            this.noInsuranceRB.Location = new System.Drawing.Point(17, 19);
            this.noInsuranceRB.Name = "noInsuranceRB";
            this.noInsuranceRB.Size = new System.Drawing.Size(89, 17);
            this.noInsuranceRB.TabIndex = 0;
            this.noInsuranceRB.TabStop = true;
            this.noInsuranceRB.Text = "No Insurance";
            this.noInsuranceRB.UseVisualStyleBackColor = true;
            // 
            // addNightLB
            // 
            this.addNightLB.FormattingEnabled = true;
            this.addNightLB.Items.AddRange(new object[] {
            "None",
            "1 Night - $100",
            "2 Nights- $200",
            "3 Nights- $300"});
            this.addNightLB.Location = new System.Drawing.Point(284, 255);
            this.addNightLB.Name = "addNightLB";
            this.addNightLB.Size = new System.Drawing.Size(120, 69);
            this.addNightLB.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(284, 236);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Additional Nights";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(284, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Location / Lodging Fees";
            // 
            // outputLbl
            // 
            this.outputLbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.outputLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLbl.Location = new System.Drawing.Point(12, 267);
            this.outputLbl.Name = "outputLbl";
            this.outputLbl.Size = new System.Drawing.Size(212, 121);
            this.outputLbl.TabIndex = 8;
            // 
            // calBtn
            // 
            this.calBtn.Location = new System.Drawing.Point(16, 406);
            this.calBtn.Name = "calBtn";
            this.calBtn.Size = new System.Drawing.Size(79, 64);
            this.calBtn.TabIndex = 9;
            this.calBtn.Text = "Calculate";
            this.calBtn.UseVisualStyleBackColor = true;
            this.calBtn.Click += new System.EventHandler(this.calBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(168, 406);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(79, 64);
            this.exitBtn.TabIndex = 10;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(452, 482);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.calBtn);
            this.Controls.Add(this.outputLbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.addNightLB);
            this.Controls.Add(this.insuranceGB);
            this.Controls.Add(this.extraGB);
            this.Controls.Add(this.locationLB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.workshopLB);
            this.Name = "Form1";
            this.Text = "Workshop";
            this.extraGB.ResumeLayout(false);
            this.extraGB.PerformLayout();
            this.insuranceGB.ResumeLayout(false);
            this.insuranceGB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox workshopLB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox locationLB;
        private System.Windows.Forms.GroupBox extraGB;
        private System.Windows.Forms.CheckBox socialEventCB;
        private System.Windows.Forms.CheckBox securityCB;
        private System.Windows.Forms.CheckBox programmingCB;
        private System.Windows.Forms.GroupBox insuranceGB;
        private System.Windows.Forms.RadioButton insuranceRB;
        private System.Windows.Forms.RadioButton noInsuranceRB;
        private System.Windows.Forms.ListBox addNightLB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label outputLbl;
        private System.Windows.Forms.Button calBtn;
        private System.Windows.Forms.Button exitBtn;
    }
}

