﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Gunn, Tony
//09/29/2017
//This program will calculate the total for the trip
namespace WorkshopHw
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //set variables
        int days = 0;
        double regFee = 0;
        double locationFee = 0;
        double total = 0;
        double extraFee = 0;
        double insureFee = 0;
        double addNightsFee = 0;
        

        string output = "";
        string name = "";
        string workshop = "";
        string location = "";
        string program = "";
        string addNights = "";
        string cityName = "";

        private void calBtn_Click(object sender, EventArgs e)
        {
            
            //start of the If statement and nested if statement
            if (workshopLB.SelectedIndex != -1)
            {
                workshop = workshopLB.SelectedIndex.ToString();
                //switch for workshop
                switch (workshop)
                {
                    case "Handling Stress":
                        name = "Handling Stress";
                        days = 3;
                        regFee = 1000;
                        total += 1000;
                        break;

                    case "Time Management":
                        name = "Time Management";
                        days = 3;
                        regFee = 800;
                        total += 800;
                        break;
                    case "Supervision Skills":
                        name = "Supervision Skills";
                        days = 3;
                        regFee = 1500;
                        total += 1500;
                        break;
                    case "Negotiation":
                        name = "Negotiation";
                        days = 5;
                        regFee = 1300;
                        total += 1300;
                        break;
                    case "How to Interview":
                        name = "How to Interview";
                        days = 1;
                        regFee = 500;
                        total += 500;
                        break;

                }
                if (locationLB.SelectedIndex != -1)
                    {
                    location = locationLB.SelectedIndex.ToString();
                    //switch for location
                    switch(location)
                    {
                        case "Austin":
                            cityName = "Austin";
                            locationFee = 150;
                            total += 150;
                            break;

                        case "Chicago":
                            cityName = "Chicago";
                            locationFee = 225;
                            total += 225;
                            break;

                        case "Dallas":
                            cityName = "Dallas";
                            locationFee = 175;
                            total += 175;
                            break;

                        case "Orlando":
                            cityName = "Orlando";
                            locationFee = 300;
                            total += 300;
                            break;

                        case "Phoenix":
                            cityName = "Phoenix";
                            locationFee = 175;
                            total += 175;
                            break;

                        case "Raleigh":
                            cityName = "Raleigh";
                            locationFee = 150;
                            total += 150;
                            break;
                    }
                    //if else if statement for extra add-ons
                     if (programmingCB.Checked)
                         {
                            extraFee = 125;
                            total += 125;
                            program = "C# Programming Training";
                         }
                     else if (securityCB.Checked)
                        {
                            extraFee = 125;
                        total += 125;
                        program = "Security Training";
                        }
                    if (socialEventCB.Checked)
                        {
                            extraFee = 25;
                        total += 25;
                        program = "Social Event Extra";
                    }

                    //If else if Statement to store insurance selection


                    if (noInsuranceRB.Checked)
                    {
                        insureFee = 0;
                        total += 0;

                    }
                    else if (insuranceRB.Checked)
                    {
                        insureFee = 30;
                        total += 30;

                    }
                   
                    //If statement to determine the amount of extra nights

                    if (addNightLB.SelectedIndex != -1)
                    {
                        addNights = addNightLB.SelectedIndex.ToString();
                        //switch for extra nights
                        switch (addNights)
                        {
                            case "None":
                                addNightsFee = 0;
                                addNights = "0";
                                total += 0;
                                break;

                            case "1 Night":
                                addNightsFee = 100;
                                total += 100;
                                addNights = "1";

                                break;
                            case "2 Nights":
                                addNightsFee = 200;
                                total += 200;
                                addNights = "2";
                                break;
                            case "3 Nights":
                                addNightsFee = 300;
                                total += 300;
                                addNights = "3";
                                break;
                            
                        }
                        // Data cal
                        total = regFee + locationFee + extraFee +
                            insureFee + addNightsFee;



                        // output data entered by the user

                        output = "Workshop: " + name +
                             "\n Location: " + cityName +
                             "\n Program Extras: " + program +
                             "\n Insurance: " + insureFee.ToString("c") +
                             "\n Additional Nights: " + addNights  +
                             "\n The total cost of the trip is: " + total.ToString("c");

                        outputLbl.Text = output;

                    }
                }
                else
                    {
                    MessageBox.Show("Please Select a Location");
                    }
                }
            else
                {
                MessageBox.Show("Please Select a Workshop Package");
                }
                
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
