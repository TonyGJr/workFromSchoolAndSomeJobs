﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomNumberEx
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showBtn_Click(object sender, EventArgs e)
        {
            // show a random number in label

            //create a random object

            Random num = new Random();

            double number = 0;
            int highValue = 0;

                // high value number

            highValue = int.Parse(numberTB.Text);

            // get a random number based upon the highest value
            
            number = num.Next(highValue) +1;

            //display the output

            displayLbl.Text = number.ToString();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // this is the default event for the form...

            MessageBox.Show("Hello to Random Numbers!!!");
        }
    }
}
