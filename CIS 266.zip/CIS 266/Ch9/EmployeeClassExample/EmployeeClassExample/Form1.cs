﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeClassExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcPayrollBtn_Click(object sender, EventArgs e)
        {
            string name = "";
            double rate = 0;
            double hours = 0;
            double grossPay = 0;


            name = nameTB.Text;
            rate = Convert.ToDouble(rateTB.Text);
            hours = Convert.ToDouble(hoursTB.Text);

            Employee employee = new Employee(name, rate, hours);

            grossPay = employee.calcGrossPay();

            displayLbl.Text = "Name: " + employee.Name + "\n"
                              + "Rate: " + employee.Rate + "\n"
                              + "Gross Pay: " + grossPay.ToString("c2");
            
        }
    }
}
