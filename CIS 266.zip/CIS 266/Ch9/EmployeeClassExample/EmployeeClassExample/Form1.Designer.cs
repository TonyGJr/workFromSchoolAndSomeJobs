﻿namespace EmployeeClassExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nameTB = new System.Windows.Forms.TextBox();
            this.rateTB = new System.Windows.Forms.TextBox();
            this.hoursTB = new System.Windows.Forms.TextBox();
            this.displayLbl = new System.Windows.Forms.Label();
            this.calcPayrollBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Rate:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(44, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Hours:";
            // 
            // nameTB
            // 
            this.nameTB.Location = new System.Drawing.Point(147, 63);
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(133, 20);
            this.nameTB.TabIndex = 3;
            // 
            // rateTB
            // 
            this.rateTB.Location = new System.Drawing.Point(147, 115);
            this.rateTB.Name = "rateTB";
            this.rateTB.Size = new System.Drawing.Size(133, 20);
            this.rateTB.TabIndex = 4;
            // 
            // hoursTB
            // 
            this.hoursTB.Location = new System.Drawing.Point(147, 168);
            this.hoursTB.Name = "hoursTB";
            this.hoursTB.Size = new System.Drawing.Size(133, 20);
            this.hoursTB.TabIndex = 5;
            // 
            // displayLbl
            // 
            this.displayLbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.displayLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayLbl.Location = new System.Drawing.Point(78, 207);
            this.displayLbl.Name = "displayLbl";
            this.displayLbl.Size = new System.Drawing.Size(252, 111);
            this.displayLbl.TabIndex = 6;
            // 
            // calcPayrollBtn
            // 
            this.calcPayrollBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calcPayrollBtn.Location = new System.Drawing.Point(130, 336);
            this.calcPayrollBtn.Name = "calcPayrollBtn";
            this.calcPayrollBtn.Size = new System.Drawing.Size(132, 44);
            this.calcPayrollBtn.TabIndex = 7;
            this.calcPayrollBtn.Text = "Calc Payroll";
            this.calcPayrollBtn.UseVisualStyleBackColor = true;
            this.calcPayrollBtn.Click += new System.EventHandler(this.calcPayrollBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 401);
            this.Controls.Add(this.calcPayrollBtn);
            this.Controls.Add(this.displayLbl);
            this.Controls.Add(this.hoursTB);
            this.Controls.Add(this.rateTB);
            this.Controls.Add(this.nameTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Employee Pay";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nameTB;
        private System.Windows.Forms.TextBox rateTB;
        private System.Windows.Forms.TextBox hoursTB;
        private System.Windows.Forms.Label displayLbl;
        private System.Windows.Forms.Button calcPayrollBtn;
    }
}

