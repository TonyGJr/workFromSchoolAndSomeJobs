﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassExample
{
    public class Employee
    {
        private string _name;
        private double _rate;
        private double _hours;




        public Employee(string theName, double theRate, double theHours)
        {
            Name = theName;
            Rate = theRate;
            Hours = theHours;
         }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public double Rate
        {
            get { return _rate; }
            set { _rate = value; }
        }

        public double Hours
        {
            get { return _hours; }
            set { _hours = value; }
        }

        public double calcGrossPay()
        {
            double otPay = 0;
            double regPay = 0;
            double grossPay = 0;

            if (_hours > 40)
            {
                otPay = (_hours - 40) * (_rate * 1.5);
                regPay = _rate * 40;
                grossPay = otPay + regPay;
            }
            else
            {
                grossPay = _rate * _hours;
            }


            return grossPay;
        }
    }
}
