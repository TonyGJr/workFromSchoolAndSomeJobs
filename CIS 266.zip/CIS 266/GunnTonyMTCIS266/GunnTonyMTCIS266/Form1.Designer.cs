﻿namespace GunnTonyMTCIS266
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.booksTB = new System.Windows.Forms.TextBox();
            this.suppliesTB = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.studEmpDiscRBtn = new System.Windows.Forms.RadioButton();
            this.schAthlDiscRBtn = new System.Windows.Forms.RadioButton();
            this.noDiscRBtn = new System.Windows.Forms.RadioButton();
            this.displayLbl = new System.Windows.Forms.Label();
            this.calcBtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Books:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Supplies:";
            // 
            // booksTB
            // 
            this.booksTB.Location = new System.Drawing.Point(135, 71);
            this.booksTB.Name = "booksTB";
            this.booksTB.Size = new System.Drawing.Size(100, 20);
            this.booksTB.TabIndex = 2;
            // 
            // suppliesTB
            // 
            this.suppliesTB.Location = new System.Drawing.Point(135, 111);
            this.suppliesTB.Name = "suppliesTB";
            this.suppliesTB.Size = new System.Drawing.Size(100, 20);
            this.suppliesTB.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.noDiscRBtn);
            this.groupBox1.Controls.Add(this.schAthlDiscRBtn);
            this.groupBox1.Controls.Add(this.studEmpDiscRBtn);
            this.groupBox1.Location = new System.Drawing.Point(317, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 126);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Discount";
            // 
            // studEmpDiscRBtn
            // 
            this.studEmpDiscRBtn.AutoSize = true;
            this.studEmpDiscRBtn.Location = new System.Drawing.Point(36, 19);
            this.studEmpDiscRBtn.Name = "studEmpDiscRBtn";
            this.studEmpDiscRBtn.Size = new System.Drawing.Size(118, 17);
            this.studEmpDiscRBtn.TabIndex = 0;
            this.studEmpDiscRBtn.TabStop = true;
            this.studEmpDiscRBtn.Text = "Stud/Emp Discount";
            this.studEmpDiscRBtn.UseVisualStyleBackColor = true;
            // 
            // schAthlDiscRBtn
            // 
            this.schAthlDiscRBtn.AutoSize = true;
            this.schAthlDiscRBtn.Location = new System.Drawing.Point(36, 57);
            this.schAthlDiscRBtn.Name = "schAthlDiscRBtn";
            this.schAthlDiscRBtn.Size = new System.Drawing.Size(129, 17);
            this.schAthlDiscRBtn.TabIndex = 1;
            this.schAthlDiscRBtn.TabStop = true;
            this.schAthlDiscRBtn.Text = "Scholar/Athl Discount";
            this.schAthlDiscRBtn.UseVisualStyleBackColor = true;
            // 
            // noDiscRBtn
            // 
            this.noDiscRBtn.AutoSize = true;
            this.noDiscRBtn.Location = new System.Drawing.Point(36, 93);
            this.noDiscRBtn.Name = "noDiscRBtn";
            this.noDiscRBtn.Size = new System.Drawing.Size(84, 17);
            this.noDiscRBtn.TabIndex = 2;
            this.noDiscRBtn.TabStop = true;
            this.noDiscRBtn.Text = "No Discount";
            this.noDiscRBtn.UseVisualStyleBackColor = true;
            // 
            // displayLbl
            // 
            this.displayLbl.BackColor = System.Drawing.Color.GreenYellow;
            this.displayLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayLbl.Location = new System.Drawing.Point(61, 241);
            this.displayLbl.Name = "displayLbl";
            this.displayLbl.Size = new System.Drawing.Size(250, 130);
            this.displayLbl.TabIndex = 5;
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(119, 384);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(129, 51);
            this.calcBtn.TabIndex = 6;
            this.calcBtn.Text = "Calculate";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 456);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.displayLbl);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.suppliesTB);
            this.Controls.Add(this.booksTB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Baker Bookstore";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox booksTB;
        private System.Windows.Forms.TextBox suppliesTB;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton noDiscRBtn;
        private System.Windows.Forms.RadioButton schAthlDiscRBtn;
        private System.Windows.Forms.RadioButton studEmpDiscRBtn;
        private System.Windows.Forms.Label displayLbl;
        private System.Windows.Forms.Button calcBtn;
    }
}

