﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GunnTonyMTCIS266
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcBtn_Click(object sender, EventArgs e)
        {
            double books = 0;
            double charges = 0;
            double disc = 0;
            double supplies = 0;
            double subtotal = 0;

            if (ValidationCheck(theBooks: ref books, theSupplies: ref supplies))
            {
                charges = Charges(theBooks: ref books, theSupplies: ref supplies);
                disc = CalcDiscount(theSubTotal: ref subtotal);

            }

            DisplayMethod(theSubtotal: ref subtotal, theBooks: ref books, theSupplies: ref supplies, theDisc: ref disc);

        }

        private bool ValidationCheck(ref double theSupplies, ref double theBooks)
        {
            bool InputValid = false;
            if (double.TryParse(booksTB.Text, out theBooks))
            {
                if (double.TryParse(suppliesTB.Text, out theSupplies))
                {
                    InputValid = true;
                }

                else
                {
                    MessageBox.Show("Please Enter a Number In the Supplies Field");
                }

            }
            else
            {
                MessageBox.Show("Please Enter A Number in the Books Field");
            }

            return InputValid;
        }

        private double Charges(ref double theSupplies, ref double theBooks)
        {
            double subtotal = 0;

            subtotal = theBooks + theSupplies;

            return subtotal;
        }


        private double CalcDiscount(ref double theSubTotal)
        {
            double discAmt = 0;


            if (studEmpDiscRBtn.Checked)
            {
                discAmt = .10;
            }
            else
            {
                discAmt = 0;
            }
            if (schAthlDiscRBtn.Checked)
            {
                discAmt = .50;
            }
            else
            {
                discAmt = 0;
            }
            if (noDiscRBtn.Checked)
            {
                discAmt = 0;
            }

            discAmt = theSubTotal * discAmt;

            return discAmt;
        }

        private void DisplayMethod(ref double theSubtotal, ref double theBooks, ref double theSupplies, ref double theDisc)
        {
            double total = 0;

            total = theSubtotal - theDisc;

            displayLbl.Text = "Baker Bookstore" +
                "\n Subtotal: " + theSubtotal.ToString("c") +
                "\n Discount: " + theDisc.ToString("c") +
                "\n Total: " + total.ToString("c");

        }
    }

}
